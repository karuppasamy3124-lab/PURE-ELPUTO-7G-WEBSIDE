/* =====================================================
   PURE EV ePLUTO 7G
   MAIN JAVASCRIPT
===================================================== */


/* =====================================================
   PRODUCT DATA
=====================================================

   IMPORTANT:
   Replace "—" with verified official specifications
   from the correct PURE EV brochure / product page.

===================================================== */

const variants = {

    cx: {
        id: "cx",
        name: "ePluto 7G CX",

        image: "red.webp",
        imageNote: "A CX-specific product image was not supplied; showing the available ePluto 7G reference image.",

        speed: "—",
        range: "—",
        battery: "—",
        load: "—",
        gradeability: "—",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",

        colours: [
            {
                name: "Red",
                image: "red.webp",
                views: ["red.webp"]
            },
            {
                name: "White",
                image: "images.jpg",
                views: ["images.jpg", "images (4).jpg", "download (1).jpg"]
            }
        ]
    },


    "7g": {
        id: "7g",
        name: "ePluto 7G",

        image: "red.webp",
        imageNote: "",

        speed: "—",
        range: "—",
        battery: "—",
        load: "—",
        gradeability: "—",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",

        colours: [
            {
                name: "Red",
                image: "red.webp",
                views: ["red.webp"]
            },
            {
                name: "White",
                image: "images.jpg",
                views: ["images.jpg", "images (4).jpg", "download (1).jpg"]
            },
            {
                name: "Grey",
                image: "images (1).jpg",
                views: ["images (1).jpg", "images (3).jpg"]
            }
        ]
    },


    pro: {
        id: "pro",
        name: "ePluto 7G Pro",

        image: "red.webp",
        imageNote: "A Pro-specific product image was not supplied; showing the available ePluto 7G reference image.",

        speed: "—",
        range: "—",
        battery: "—",
        load: "—",
        gradeability: "—",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",

        colours: [
            {
                name: "Standard",
                image: "red.webp",
                views: ["red.webp"]
            }
        ]
    },


    max: {
        id: "max",
        name: "ePluto 7G Max",

        image: "red.webp",
        imageNote: "A Max-specific product image was not supplied; showing the available ePluto 7G reference image.",

        speed: "—",
        range: "—",
        battery: "—",
        load: "—",
        gradeability: "—",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",

        colours: [
            {
                name: "Standard",
                image: "red.webp",
                views: ["red.webp"]
            }
        ]
    }
};

const sharedColours = [
    { name: "Red", image: "red.webp", views: ["red.webp"] },
    { name: "White", image: "images.jpg", views: ["images.jpg", "images (4).jpg", "download (1).jpg"] },
    { name: "Grey", image: "images (1).jpg", views: ["images (1).jpg", "images (3).jpg"] }
];

const variantSpecifications = {
    "7g": {
        name: "ePluto 7G",
        image: "red.webp",
        defaultColour: "Red",
        speed: "60 KM/H",
        range: "111–151 KM",
        officialRange: "90–151 KM",
        battery: "2.4 KWH",
        load: "150 KG",
        gradeability: "14 Degree",
        motor: "—",
        batteryType: "Lithium-ion",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "Smart BMS with Mobile App",
        connectivity: "Bluetooth",
        reverse: "Available",
        imageNote: "",
        features: [
            ["↩", "Reverse Mode", "Helps manoeuvre the scooter in reverse."],
            ["⌁", "Highly Efficient Powertrain", "PURE EV powertrain feature."],
            ["↗", "Hill-Start Assist", "Supports a controlled start on an incline."],
            ["↘", "Down-Hill Assist", "Electronic rider assistance on descents."],
            ["⚡", "Swift Throttle Response", "Responsive electric acceleration."],
            ["◎", "Parking Assist", "Assistance for low-speed parking manoeuvres."],
            ["◉", "Smart AI for Battery Longevity", "Battery-management feature listed by PURE EV."],
            ["↝", "Coasting Regeneration", "Regenerative feature listed by PURE EV."],
            ["⟲", "Smart Regenerative Braking", "Regenerative braking feature listed by PURE EV."],
            ["◌", "Enhanced Electronic Braking", "Electronic braking feature listed by PURE EV."]
        ]
    },
    pro: {
        name: "ePluto 7G PRO",
        image: "images (1).jpg",
        defaultColour: "Grey",
        speed: "60 KM/H",
        range: "131–171 KM",
        battery: "3 KWH",
        load: "150 KG",
        gradeability: "12 Degree",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",
        imageNote: "The supplied images do not identify a PRO-specific model; the available ePluto reference image is shown.",
        features: []
    },
    max: {
        name: "ePluto 7G MAX",
        image: "images.jpg",
        defaultColour: "White",
        speed: "60 KM/H",
        range: "150–211 KM",
        battery: "3.5 KWH",
        load: "150 KG",
        gradeability: "12 Degree",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",
        imageNote: "The supplied images do not identify a MAX-specific model; the available ePluto reference image is shown.",
        features: []
    },
    cx: {
        name: "ePluto 7G CX",
        image: "images (4).jpg",
        defaultColour: "Red",
        speed: "47 KM/H",
        range: "85–101 KM",
        battery: "1.8 KWH",
        load: "100 KG",
        gradeability: "7 Degree",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",
        imageNote: "The supplied images do not identify a CX-specific model; the available ePluto reference image is shown.",
        features: []
    }
};

Object.entries(variantSpecifications).forEach(([id, specifications]) => {
    const colours = id === "cx"
        ? sharedColours.map(colour => colour.name === "Red"
            ? { ...colour, image: "images (4).jpg", views: ["images (4).jpg"] }
            : colour)
        : sharedColours;
    Object.assign(variants[id], specifications, { colours });
});
const variantOrder = ["7g", "pro", "max", "cx"];


/* =====================================================
   CURRENT STATE
===================================================== */

let selectedVariant = "7g";
let selectedColour = null;


/* =====================================================
   DOM ELEMENTS
===================================================== */

const welcomePage =
    document.getElementById("welcomePage");

const mainWebsite =
    document.getElementById("mainWebsite");

const entryForm =
    document.getElementById("entryForm");

const heroScooter =
    document.getElementById("heroScooter");

const colourScooter =
    document.getElementById("colourScooter");

const partsScooter =
    document.getElementById("partsScooter");

const detailCropImage =
    document.getElementById("detailCropImage");

const vehicleCanvas =
    document.getElementById("vehicleCanvas");

const variantContainer =
    document.getElementById("variantContainer");

const colourButtons =
    document.getElementById("colourButtons");


function updateImageSurfaces(colour) {
    const usesPhotographicBackground =
        colour.name === "White" || colour.name === "Grey";
    [
        ".hero-image-container",
        ".colour-preview",
        ".gallery-image-wrapper",
        ".parts-viewer"
    ].forEach(selector => {
        document.querySelector(selector).classList.toggle(
            "light-image-surface",
            usesPhotographicBackground
        );
    });
}

function transitionImage(image, source) {
    if (image.getAttribute("src") === source) {
        return;
    }
    image.classList.add("image-switching");
    window.setTimeout(() => {
        image.addEventListener("load", () => image.classList.remove("image-switching"), { once: true });
        image.src = source;
    }, 120);
}

function playLeafIntro() {
    const intro = document.getElementById("leafIntro");
    if (!intro || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        return;
    }
    for (let index = 0; index < 12; index += 1) {
        const leaf = document.createElement("span");
        leaf.className = "leaf-intro-leaf";
        leaf.style.setProperty("--leaf-left", `${Math.random() * 100}%`);
        leaf.style.setProperty("--leaf-size", `${9 + Math.random() * 11}px`);
        leaf.style.setProperty("--leaf-angle", `${Math.round(Math.random() * 180)}deg`);
        leaf.style.setProperty("--leaf-duration", `${3.1 + Math.random() * 1.4}s`);
        leaf.style.setProperty("--leaf-delay", `${Math.random() * .7}s`);
        leaf.style.setProperty("--leaf-drift", `${Math.round((Math.random() - .5) * 150)}px`);
        intro.appendChild(leaf);
    }
    window.setTimeout(() => intro.replaceChildren(), 5200);
}

playLeafIntro();


/* =====================================================
   PAGE LOADER
===================================================== */

window.addEventListener("load", () => {

    const loader = document.getElementById("loader");

    setTimeout(() => {

        loader.style.opacity = "0";

        setTimeout(() => {
            loader.style.display = "none";
        }, 600);

    }, 700);

});


/* =====================================================
   ENTRY FORM
===================================================== */

entryForm.addEventListener("submit", function (event) {

    event.preventDefault();

    const name =
        document.getElementById("fullName").value.trim();

    const phone =
        document.getElementById("phone").value.trim();

    const nameError =
        document.getElementById("nameError");

    const phoneError =
        document.getElementById("phoneError");

    const entryStatus =
        document.getElementById("entryStatus");

    const submitButton =
        entryForm.querySelector('button[type="submit"]');
    const submitLabel =
        document.getElementById("entryButtonLabel");


    nameError.textContent = "";
    phoneError.textContent = "";
    entryStatus.textContent = "";
    entryStatus.classList.remove("error");

    let valid = true;


    if (!name) {
        nameError.textContent =
            "Please enter your name.";

        valid = false;
    }


    const indianPhone =
        /^[6-9][0-9]{9}$/;


    if (!indianPhone.test(phone)) {

        phoneError.textContent =
            "Enter a valid 10-digit Indian mobile number.";

        valid = false;
    }


    if (!valid) {
        return;
    }

    submitButton.disabled = true;
    submitButton.setAttribute("aria-busy", "true");
    submitLabel.textContent = "ENTERING SHOWROOM...";
    entryStatus.textContent = "Entering Showroom...";

    try {
        localStorage.setItem("showroomUser", JSON.stringify({ name, phone }));
    } catch {
        entryStatus.textContent =
            "Entering Showroom... Your browser did not allow saving these details.";
    }

    window.setTimeout(() => {
        welcomePage.style.transition =
            "opacity .7s ease, transform .7s ease";

        welcomePage.style.opacity = "0";
        welcomePage.style.transform = "scale(1.03)";

        window.setTimeout(() => {
            welcomePage.style.display = "none";
            mainWebsite.classList.add("active");
            document.body.classList.remove("no-scroll");
            updateVariant(selectedVariant);
            window.scrollTo({
                top: 0,
                behavior: "instant"
            });
        }, 700);
    }, 180);

});

/* =====================================================
   NAVIGATION
===================================================== */

const menuButton =
    document.getElementById("menuButton");

const navMenu =
    document.getElementById("navMenu");


menuButton.addEventListener("click", () => {

    navMenu.classList.toggle("open");
    menuButton.setAttribute(
        "aria-expanded",
        String(navMenu.classList.contains("open"))
    );

});


document.querySelectorAll(".navbar nav a")
    .forEach(link => {

        link.addEventListener("click", () => {

            navMenu.classList.remove("open");
            menuButton.setAttribute("aria-expanded", "false");

        });

    });


/* =====================================================
   CREATE VARIANT CARDS
===================================================== */

function renderVariants() {

    variantContainer.innerHTML = "";


    variantOrder.map(id => variants[id]).forEach(variant => {

        const card =
            document.createElement("button");

        card.className =
            "variant-card";
        card.type = "button";
        card.setAttribute("aria-pressed", String(variant.id === selectedVariant));


        if (variant.id === selectedVariant) {
            card.classList.add("active");
        }

        const image = document.createElement("img");
        image.src = variant.image;
        image.alt = "";

        const title = document.createElement("h3");
        title.textContent = variant.name;

        const description = document.createElement("p");
        description.textContent = variant.imageNote ||
            "Select to explore this variant and its available colours.";

        card.append(image, title, description);


        card.addEventListener("click", () => {

            updateVariant(variant.id);

        });


        variantContainer.appendChild(card);

    });

}


/* =====================================================
   UPDATE VARIANT
===================================================== */

function updateVariant(id) {

    if (!variants[id]) {
        return;
    }


    selectedVariant = id;

    const variant = variants[id];


    /* Default colour */

    selectedColour =
        variant.colours.find(colour => colour.name === variant.defaultColour) ||
        variant.colours[0];


    /* Update scooter images */

    transitionImage(heroScooter, selectedColour.image);
    transitionImage(colourScooter, selectedColour.image);
    transitionImage(partsScooter, selectedColour.image);
    transitionImage(detailCropImage, selectedColour.image);
    updateImageSurfaces(selectedColour);

    partsScooter.alt =
        `Interactive ${variant.name} in ${selectedColour.name}`;

    document.getElementById("explorerVariantName")
        .textContent = variant.name;

    document.getElementById("floatingModelName")
        .textContent = variant.name;

    /* Update names */

    document.getElementById(
        "selectedVariantName"
    ).textContent = variant.name;


    document.getElementById(
        "selectedColourName"
    ).textContent = selectedColour.name;

    document.getElementById("colourAssetNote").textContent =
        variant.imageNote || "";

    closePartModal();

    /* Hero specifications */

    document.getElementById("heroSpeed")
        .textContent = variant.speed;

    document.getElementById("heroRange")
        .textContent = variant.range;

    document.getElementById("heroBattery")
        .textContent = variant.battery;

    document.getElementById("heroLoad")
        .textContent = variant.load;
    document.getElementById("batteryPercent")
        .textContent = variant.battery;


    /* Full specification */

    updateSpecifications(variant);


    /* Colours */

    renderColours(variant);


    /* Variant active state */

    document.querySelectorAll(".variant-card")
        .forEach(card => {

            card.classList.remove("active");
            card.setAttribute("aria-pressed", "false");

        });


    const cards =
        document.querySelectorAll(".variant-card");


    const index =
        variantOrder.indexOf(id);


    if (cards[index]) {
        cards[index].classList.add("active");
        cards[index].setAttribute("aria-pressed", "true");
    }


    /* Range */

    updateRange(variant);
    renderFeatures(variant);
    animateSpecCards(variant);


    /* Gallery */

    resetGallery();

}


/* =====================================================
   UPDATE SPECIFICATIONS
===================================================== */

function updateSpecifications(variant) {

    document.getElementById("specSpeed")
        .textContent = variant.speed;

    document.getElementById("specRange")
        .textContent = variant.officialRange || variant.range;

    document.getElementById("specGradeability")
        .textContent = variant.gradeability;

    document.getElementById("specMotor")
        .textContent = variant.motor;

    document.getElementById("specBattery")
        .textContent = variant.battery;

    document.getElementById("specBatteryType")
        .textContent = variant.batteryType;

    document.getElementById("specCharging")
        .textContent = variant.charging;

    document.getElementById("specPortable")
        .textContent = variant.portable;

    document.getElementById("specFrontBrake")
        .textContent = variant.frontBrake;

    document.getElementById("specRearBrake")
        .textContent = variant.rearBrake;

    document.getElementById("specTyre")
        .textContent = variant.tyre;

    document.getElementById("specWheel")
        .textContent = variant.wheel;

    document.getElementById("specLoad")
        .textContent = variant.load;

    document.getElementById("specBms")
        .textContent = variant.bms;

    document.getElementById("specConnectivity")
        .textContent = variant.connectivity;

    document.getElementById("specReverse")
        .textContent = variant.reverse;

}

function renderFeatures(variant) {
    const featureGrid = document.getElementById("experienceGrid");
    featureGrid.replaceChildren();
    const featureList = variant.features.length
        ? variant.features
        : [["◎", "Variant details", "Feature equipment for this brochure variant has not been independently verified."]];

    featureList.forEach(([icon, title, description]) => {
        const card = document.createElement("article");
        card.className = "experience-card";
        const symbol = document.createElement("div");
        symbol.className = "experience-icon";
        symbol.setAttribute("aria-hidden", "true");
        symbol.textContent = icon;
        const heading = document.createElement("h3");
        heading.textContent = title;
        const detail = document.createElement("p");
        detail.textContent = description;
        card.append(symbol, heading, detail);
        featureGrid.appendChild(card);
    });
}


/* =====================================================
   COLOUR SELECTOR
===================================================== */

function renderColours(variant) {

    colourButtons.innerHTML = "";


    variant.colours.forEach((colour, index) => {

        const button =
            document.createElement("button");

        button.className = "colour-btn";
        button.type = "button";
        button.setAttribute("aria-pressed", String(colour.name === selectedColour.name));

        if (colour.name === selectedColour.name) {
            button.classList.add("active");
        }


        button.textContent =
            colour.name;


        button.addEventListener("click", () => {

            selectColour(colour);

        });


        colourButtons.appendChild(button);

    });


    document.getElementById("colourDisplay")
        .textContent = selectedColour.name;

}


function selectColour(colour) {

    selectedColour = colour;


    transitionImage(heroScooter, colour.image);
    transitionImage(colourScooter, colour.image);
    transitionImage(partsScooter, colour.image);
    transitionImage(detailCropImage, colour.image);
    updateImageSurfaces(colour);


    document.getElementById(
        "selectedColourName"
    ).textContent = colour.name;


    document.getElementById(
        "colourDisplay"
    ).textContent = colour.name;


    document.querySelectorAll(".colour-btn")
        .forEach(button => {

            button.classList.remove("active");
        button.setAttribute("aria-pressed", "false");

        if (button.textContent === colour.name) {
            button.classList.add("active");
            button.setAttribute("aria-pressed", "true");
        }

    });

    document.getElementById("colourAssetNote").textContent =
    variants[selectedVariant].imageNote || "";
    partsScooter.alt =
    `Interactive ${variants[selectedVariant].name} in ${colour.name}`;
    closePartModal();
    resetGallery();

}


/* =====================================================
   RANGE
===================================================== */

function updateRange(variant) {

    const rangeElement =
        document.getElementById("rangeValue");

    rangeElement.textContent =
        variant.range;

}

let specAnimationRun = 0;
let rangeTrailTimer = null;

function animateSpecCards(variant) {
    if (!mainWebsite.classList.contains("active")) {
        return;
    }
    const run = ++specAnimationRun;
    const speed = Number.parseInt(variant.speed, 10);
    const load = Number.parseInt(variant.load, 10);
    const speedElement = document.getElementById("heroSpeed");
    const rangeElement = document.getElementById("heroRange");
    const batteryElement = document.getElementById("heroBattery");
    const batteryFill = document.getElementById("heroBatteryFill");
    const loadElement = document.getElementById("heroLoad");
    const loadIcon = document.querySelector(".load-icon");
    const speedCard = speedElement.closest(".stat-card");
    const rangeCard = rangeElement.closest(".stat-card");
    const batteryCard = batteryElement.closest(".stat-card");
    const loadCard = loadElement.closest(".stat-card");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    [speedCard, rangeCard, batteryCard, loadCard].forEach(card => {
        card.classList.remove("energy-complete", "range-active", "stable");
    });
    if (rangeTrailTimer) {
        window.clearTimeout(rangeTrailTimer);
        rangeTrailTimer = null;
    }
    speedCard.classList.remove("electric-finish");
    speedElement.textContent = "0 KM/H";
    batteryElement.textContent = variant.battery;
    loadElement.textContent = "0 KG";
    batteryFill.style.transform = "scaleX(0)";
    batteryFill.style.backgroundColor = "hsl(0 78% 54%)";
    loadIcon.style.transform = "translateY(0)";

    const finishRange = () => {
        if (run !== specAnimationRun) return;
        rangeElement.textContent = variant.range;
        rangeElement.classList.remove("range-dropping");
        void rangeElement.offsetWidth;
        rangeElement.classList.add("range-dropping");
        rangeCard.classList.add("range-active");
        rangeTrailTimer = window.setTimeout(() => rangeCard.classList.remove("range-active"), 7000);
    };

    if (reducedMotion) {
        speedElement.textContent = variant.speed;
        finishRange();
        batteryFill.style.transform = "scaleX(1)";
        batteryFill.style.backgroundColor = "hsl(120 65% 47%)";
        loadElement.textContent = variant.load;
        speedCard.classList.add("electric-finish");
        batteryCard.classList.add("energy-complete");
        loadCard.classList.add("stable");
        return;
    }

    const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    let letterIndex = 0;
    rangeElement.classList.remove("range-dropping");
    rangeElement.textContent = letters.slice(0, 1);
    const letterTimer = window.setInterval(() => {
        if (run !== specAnimationRun) {
            window.clearInterval(letterTimer);
            return;
        }
        letterIndex = (letterIndex + 1) % (letters.length - 3);
        rangeElement.textContent = letters.slice(letterIndex, letterIndex + 4);
    }, 75);
    window.setTimeout(() => {
        window.clearInterval(letterTimer);
        finishRange();
    }, 650);

    const countDuration = 2700;
    const animateCount = (element, target, suffix, duration, onComplete) => {
        if (!Number.isFinite(target)) {
            element.textContent = "—";
            if (onComplete) onComplete();
            return;
        }
        const started = performance.now();
        const frame = now => {
            if (run !== specAnimationRun) return;
            const progress = Math.min(1, (now - started) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            element.textContent = `${Math.round(target * eased)} ${suffix}`;
            if (progress < 1) {
                requestAnimationFrame(frame);
            } else if (onComplete) {
                onComplete();
            }
        };
        requestAnimationFrame(frame);
    };

    animateCount(speedElement, speed, "KM/H", countDuration, () => {
        speedElement.textContent = variant.speed;
        speedCard.classList.add("electric-finish");
    });

    const batteryStarted = performance.now();
    const fillBattery = now => {
        if (run !== specAnimationRun) return;
        const progress = Math.min(1, (now - batteryStarted) / 2900);
        const hue = Math.round(120 * progress);
        batteryFill.style.transform = `scaleX(${progress})`;
        batteryFill.style.backgroundColor = `hsl(${hue} 78% 52%)`;
        if (progress < 1) {
            requestAnimationFrame(fillBattery);
        } else {
            batteryCard.classList.add("energy-complete");
        }
    };
    requestAnimationFrame(fillBattery);

    if (Number.isFinite(load)) {
        const steps = Math.ceil(load / 10);
        const loadStarted = performance.now();
        const animateLoad = now => {
            if (run !== specAnimationRun) return;
            const progress = Math.min(1, (now - loadStarted) / countDuration);
            const completedSteps = Math.min(steps, Math.floor(progress * steps));
            const currentLoad = progress === 1
                ? load
                : Math.min(load, completedSteps * 10);
            loadElement.textContent = `${currentLoad} KG`;
            loadIcon.style.transform = `translateY(${(currentLoad / load) * 7}px)`;
            if (progress < 1) {
                requestAnimationFrame(animateLoad);
            } else {
                loadElement.textContent = variant.load;
                loadCard.classList.add("stable");
            }
        };
        requestAnimationFrame(animateLoad);
    } else {
        loadElement.textContent = "—";
    }
}


/* =====================================================
   GALLERY
===================================================== */

let selectedView = 0;
let galleryRotationTimer = null;
let galleryResumeTimer = null;
let activeHotspot = null;

const galleryViewer = document.getElementById("galleryViewer");
const galleryImage = document.getElementById("galleryImage");
const galleryControls = document.querySelector(".gallery-controls");
const partsViewer = document.querySelector(".parts-viewer");
const detailPanel = document.getElementById("partDetailPanel");

partsViewer.addEventListener("pointerdown", pauseGalleryRotation);


function getGalleryFrames() {
    return selectedColour && selectedColour.views
        ? selectedColour.views
        : [selectedColour ? selectedColour.image : "red.webp"];
}


function renderGalleryControls() {
    const frames = getGalleryFrames();
    const indicators = document.getElementById("viewIndicators");
    indicators.replaceChildren();
    document.getElementById("viewerNote").textContent = frames.length > 1
        ? "Drag, swipe, or use the controls to move between supplied product photos. This is a multi-view presentation, not a true 360° camera model."
        : "Only one suitable product image is available for this selection. Add more matching ePluto 7G photos to enable multi-view movement.";

    frames.forEach((frame, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "view-indicator";
        button.setAttribute("aria-label", `Show available product image ${index + 1}`);
        button.setAttribute("aria-pressed", String(index === selectedView));
        button.classList.toggle("active", index === selectedView);
        button.addEventListener("click", () => {
            pauseGalleryRotation();
            showGalleryView(index);
        });
        indicators.appendChild(button);
    });

    document.getElementById("previousView").disabled = frames.length < 2;
    document.getElementById("nextView").disabled = frames.length < 2;
}


function showGalleryView(index) {
    const frames = getGalleryFrames();
    if (!frames.length) {
        return;
    }

    selectedView = (index + frames.length) % frames.length;
    galleryImage.classList.add("is-changing");
    galleryImage.src = frames[selectedView];
    galleryImage.alt =
        `${variants[selectedVariant].name}, available product image ${selectedView + 1}`;

    document.getElementById("galleryTitle").textContent =
        `PRODUCT IMAGE ${selectedView + 1}`;
    document.getElementById("galleryDescription").textContent =
        `Available product photograph ${selectedView + 1} of ${frames.length}. These images are not a true 360° camera sequence.`;

    renderGalleryControls();
    requestAnimationFrame(() => galleryImage.classList.remove("is-changing"));
}


function stopGalleryRotation() {
    window.clearTimeout(galleryRotationTimer);
    galleryRotationTimer = null;
}


function scheduleGalleryRotation(delay) {
    stopGalleryRotation();
    window.clearTimeout(galleryResumeTimer);
    galleryResumeTimer = null;

    if (document.hidden || getGalleryFrames().length < 2 ||
        !mainWebsite.classList.contains("active") ||
        partsViewer.classList.contains("is-focused")) {
        return;
    }

    galleryRotationTimer = window.setTimeout(() => {
        showGalleryView(selectedView + 1);
        scheduleGalleryRotation(6500);
    }, delay);
}


function pauseGalleryRotation() {
    stopGalleryRotation();
    window.clearTimeout(galleryResumeTimer);
    galleryResumeTimer = window.setTimeout(() => {
        scheduleGalleryRotation(6500);
    }, 8000);
}


document.getElementById("previousView").addEventListener("click", () => {
    pauseGalleryRotation();
    showGalleryView(selectedView - 1);
});

document.getElementById("nextView").addEventListener("click", () => {
    pauseGalleryRotation();
    showGalleryView(selectedView + 1);
});

[galleryViewer, galleryControls].forEach(element => {
    element.addEventListener("pointerdown", pauseGalleryRotation);
    element.addEventListener("keydown", pauseGalleryRotation);
    element.addEventListener("focusin", pauseGalleryRotation);
    element.addEventListener("pointerenter", event => {
        if (event.pointerType === "mouse") {
            pauseGalleryRotation();
        }
    });
});

let galleryPointerStart = null;
galleryViewer.addEventListener("pointerdown", event => {
    if (event.target.closest("button")) {
        return;
    }
    galleryPointerStart = { x: event.clientX, y: event.clientY };
    if (galleryViewer.setPointerCapture) {
        galleryViewer.setPointerCapture(event.pointerId);
    }
});

galleryViewer.addEventListener("pointerup", event => {
    if (!galleryPointerStart) {
        return;
    }
    const deltaX = event.clientX - galleryPointerStart.x;
    const deltaY = event.clientY - galleryPointerStart.y;
    galleryPointerStart = null;

    if (Math.abs(deltaX) > 38 && Math.abs(deltaX) > Math.abs(deltaY)) {
        showGalleryView(selectedView + (deltaX < 0 ? 1 : -1));
        pauseGalleryRotation();
    }
});

galleryViewer.addEventListener("pointercancel", () => {
    galleryPointerStart = null;
});

document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
        stopGalleryRotation();
        window.clearTimeout(galleryResumeTimer);
    } else {
        scheduleGalleryRotation(1500);
    }
});


function resetGallery() {
    selectedView = 0;
    showGalleryView(selectedView);
    scheduleGalleryRotation(6500);
}


/* Vehicle hotspot information uses general descriptions; no unverified numeric specifications. */
const partData = {
    headlight: {
        title: "Headlight",
        description: "The front lamp assembly is part of the scooter’s forward lighting and visibility setup.",
        tamil: "முன்புற விளக்கு, முன்னால் செல்லும் பாதையைப் பார்க்கவும் மற்றவர்கள் ஸ்கூட்டரை கவனிக்கவும் உதவுகிறது.",
        spec: "Lighting details vary by selected model and year.",
        features: "FRONT LIGHTING  ·  VISIBILITY  ·  MODEL-DEPENDENT DETAILS"
    },
    display: {
        title: "Rider display",
        description: "The dashboard area presents vehicle information to the rider.",
        tamil: "ஸ்கூட்டர் தொடர்பான தகவல்களை ஓட்டுநருக்குக் காட்டும் பகுதி இது.",
        spec: "Display functions vary by selected model and year.",
        features: "DASHBOARD AREA  ·  RIDER INFORMATION"
    },
    indicator: {
        title: "Indicator area",
        description: "The visible indicator area is part of the scooter’s signalling and visibility equipment.",
        tamil: "திரும்பும் திசையை மற்றவர்களுக்கு தெரிவிக்க இந்த சிக்னல் விளக்குகள் பயன்படுகின்றன.",
        spec: "Indicator equipment and operation vary by model and year.",
        features: "SIGNALLING  ·  RIDER VISIBILITY"
    },
    frontTyre: {
        title: "Front tyre",
        description: "The front tyre meets the road and supports steering, grip, and ride comfort.",
        tamil: "முன் டயர் சாலையுடன் தொடர்பில் இருந்து பிடிப்பு, திசை கட்டுப்பாடு மற்றும் பயண வசதிக்கு உதவுகிறது.",
        spec: "Tyre type and size vary by selected model and year.",
        features: "ROAD CONTACT  ·  STEERING  ·  GRIP"
    },
    rearTyre: {
        title: "Rear tyre",
        description: "The rear tyre supports road contact and transfers drive force to the road.",
        tamil: "பின் டயர் சாலையுடன் பிடிப்பை வழங்கி, மோட்டாரின் இயக்கத்தை சாலைக்கு கடத்த உதவுகிறது.",
        spec: "Tyre type and size vary by selected model and year.",
        features: "ROAD CONTACT  ·  DRIVE TRACTION"
    },
    battery: {
        title: "Battery area",
        description: "The battery stores electrical energy for the scooter’s electric drive system.",
        tamil: "ஸ்கூட்டரின் மின்சார இயக்கத்திற்குத் தேவையான ஆற்றலை பேட்டரி சேமிக்கிறது.",
        spec: "Battery chemistry and capacity vary by selected model and year.",
        features: "ENERGY STORAGE  ·  VEHICLE POWER"
    },
    seat: {
        title: "Seat",
        description: "The seat is the rider and passenger seating area, shaped for everyday use.",
        tamil: "ஓட்டுநரும் பயணியும் அமர்ந்து செல்லும் பகுதி இருக்கை.",
        spec: "Seat dimensions and finish vary by model.",
        features: "RIDER COMFORT  ·  EVERYDAY PRACTICALITY"
    },
    motor: {
        title: "Electric motor area",
        description: "The electric drive system converts stored electrical energy into motion.",
        tamil: "சேமிக்கப்பட்ட மின்சாரத்தை ஸ்கூட்டரை இயக்கும் சக்தியாக மோட்டார் மாற்றுகிறது.",
        spec: "Motor output varies by selected model and year.",
        features: "ELECTRIC DRIVE  ·  REAR-WHEEL MOTION"
    },
    handlebar: {
        title: "Handlebar",
        description: "The handlebar provides the rider with steering and hand-control points.",
        tamil: "ஸ்கூட்டரின் திசையை மாற்றவும் கை கட்டுப்பாடுகளை இயக்கவும் ஹேண்டில்பார் உதவுகிறது.",
        spec: "Control layout may vary by model.",
        features: "STEERING  ·  RIDER CONTROLS"
    },
    frontSuspension: {
        title: "Front suspension",
        description: "The front suspension area helps manage road movement at the front wheel.",
        tamil: "முன் சக்கரத்தில் ஏற்படும் சாலை அதிர்வுகளை கையாள சஸ்பென்ஷன் உதவுகிறது.",
        spec: "Suspension construction varies by model.",
        features: "FRONT-WHEEL SUPPORT  ·  RIDE COMFORT"
    },
    frontBrake: {
        title: "Front disc brake",
        description: "The visible front disc assembly is part of the scooter’s braking system.",
        tamil: "முன் சக்கரத்தின் வேகத்தை கட்டுப்படுத்தும் பிரேக் அமைப்பின் பகுதி இது.",
        spec: "Brake type and equipment vary by selected model and year.",
        features: "CONTROLLED DECELERATION  ·  FRONT-WHEEL BRAKING"
    },
    rearBrake: {
        title: "Rear brake area",
        description: "The rear braking assembly contributes to the scooter’s overall braking system.",
        tamil: "ஸ்கூட்டரின் வேகத்தை குறைக்க பின்புற பிரேக் அமைப்பு உதவுகிறது.",
        spec: "Brake type and equipment vary by selected model and year.",
        features: "REAR-WHEEL BRAKING  ·  MODEL-DEPENDENT DETAILS"
    },
    storage: {
        title: "Under-seat storage",
        description: "The area beneath the seat is the scooter’s under-seat storage location.",
        tamil: "இருக்கையின் கீழே சிறிய பொருட்களை வைக்க பயன்படும் சேமிப்பு இடம் உள்ளது.",
        spec: "Storage capacity and access details vary by model.",
        features: "PRACTICAL STORAGE  ·  CHECK THE SELECTED MODEL"
    },
    sidePanel: {
        title: "Side body panel",
        description: "The side panel shapes the scooter’s profile and covers part of the body structure.",
        tamil: "ஸ்கூட்டரின் பக்க வடிவத்தை உருவாக்கி உட்புற அமைப்பின் ஒரு பகுதியை மூடும் வெளிப்புற பேனல் இது.",
        spec: "Panel finish and detailing vary by colour and model.",
        features: "BODYWORK  ·  MODEL STYLING"
    },
    footboard: {
        title: "Footboard",
        description: "The footboard provides a space for the rider’s feet while seated.",
        tamil: "ஓட்டுநர் அமர்ந்து செல்லும்போது கால்களை வைக்க உதவும் தளம் இது.",
        spec: "Footboard layout varies by model.",
        features: "RIDER POSITION  ·  EVERYDAY COMFORT"
    },
    chargingPort: {
        title: "Charging-port area",
        description: "The charging connection is used to connect the vehicle to its compatible charger.",
        tamil: "பொருத்தமான சார்ஜரை இணைத்து ஸ்கூட்டரை சார்ஜ் செய்யும் இடம் இது.",
        spec: "Port position and charging details vary by selected model and year.",
        features: "CHARGING ACCESS  ·  USE THE SUPPLIED COMPATIBLE CHARGER"
    },
    tailLight: {
        title: "Rear-light area",
        description: "The rear lighting area helps make the scooter visible from behind.",
        tamil: "பின்னால் வரும் வாகனங்களுக்கு ஸ்கூட்டர் தெளிவாகத் தெரிய பின்புற விளக்கு உதவுகிறது.",
        spec: "Rear-light equipment varies by model and year.",
        features: "REAR VISIBILITY  ·  MODEL-DEPENDENT LIGHTING"
    },
    frontMudguard: {
        title: "Front mudguard",
        description: "The front mudguard covers part of the front wheel area.",
        tamil: "முன் சக்கரத்தின் ஒரு பகுதியை மூடும் முன்புற பாதுகாப்புப் பகுதி இது.",
        spec: "Construction and finish vary by model.",
        features: "FRONT BODYWORK · MODEL DETAIL"
    },
    rearBody: {
        title: "Rear body panel",
        description: "The rear bodywork shapes the scooter's side and rear profile.",
        tamil: "ஸ்கூட்டரின் பக்க மற்றும் பின்புற வடிவத்தை உருவாக்கும் உடல் பகுதி இது.",
        spec: "Panel finish varies by colour and model.",
        features: "REAR BODYWORK · MODEL STYLING"
    }
};


document.querySelectorAll(".hotspot").forEach(hotspot => {
    hotspot.addEventListener("click", () => {
        pauseGalleryRotation();
        openPartModal(hotspot);
    });
});

vehicleCanvas.addEventListener("click", event => {
    if (event.target.closest(".hotspot")) {
        return;
    }

    const bounds = vehicleCanvas.getBoundingClientRect();
    const pointX = event.clientX;
    const pointY = event.clientY;
    const nearestHotspot = [...vehicleCanvas.querySelectorAll(".hotspot")]
        .reduce((nearest, hotspot) => {
            const marker = hotspot.getBoundingClientRect();
            const distance = Math.hypot(
                marker.left + marker.width / 2 - pointX,
                marker.top + marker.height / 2 - pointY
            );
            return !nearest || distance < nearest.distance
                ? { hotspot, distance }
                : nearest;
        }, null);

    if (nearestHotspot && pointX >= bounds.left && pointX <= bounds.right &&
        pointY >= bounds.top && pointY <= bounds.bottom) {
        pauseGalleryRotation();
        openPartModal(nearestHotspot.hotspot);
    }
});

function openPartModal(hotspot) {
    const data = partData[hotspot.dataset.part];
    if (!data) {
        return;
    }

    activeHotspot = hotspot;
    document.getElementById("modalTitle").textContent = data.title;
    document.getElementById("modalDescription").textContent = data.description;
    document.getElementById("modalTamil").textContent = data.tamil;
    const selectedProduct = variants[selectedVariant];
    document.getElementById("modalSpec").textContent = hotspot.dataset.part === "battery"
        ? `${selectedProduct.battery} · ${data.spec}`
        : data.spec;
    document.getElementById("modalFeatures").textContent = data.features;
    detailCropImage.alt = `${data.title} crop from the selected scooter image`;

    document.querySelectorAll(".hotspot").forEach(button => {
        button.classList.toggle("is-selected", button === hotspot);
    });
    partsViewer.classList.add("is-focused");
    detailPanel.setAttribute("aria-hidden", "false");
    document.getElementById("closeModal").tabIndex = 0;
    document.body.classList.add("detail-open");

    const stageRect = vehicleCanvas.getBoundingClientRect();
    const stageWidth = vehicleCanvas.offsetWidth;
    const stageHeight = vehicleCanvas.offsetHeight;
    const targetX = hotspot.offsetLeft + hotspot.offsetWidth / 2;
    const targetY = hotspot.offsetTop + hotspot.offsetHeight / 2;
    const isMobile = window.matchMedia("(max-width: 700px)").matches;
    const zoom = isMobile ? 1.8 : 2.25;
    const focusX = stageRect.width * (isMobile ? 0.5 : 0.38);
    const focusY = stageRect.height * (isMobile ? 0.31 : 0.44);
    const translateX = (focusX - targetX) * zoom;
    const translateY = (focusY - targetY) * zoom;
    vehicleCanvas.style.transform =
        `translate3d(${translateX}px, ${translateY}px, 0) scale(${zoom})`;

    window.setTimeout(() => {
        if (activeHotspot === hotspot) {
            partsViewer.classList.add("callout-active");
            drawCallout();
        }
    }, 850);
    document.getElementById("closeModal").focus({ preventScroll: true });
}

partsViewer.addEventListener("click", event => {
    if (partsViewer.classList.contains("is-focused") &&
        (event.target === partsViewer ||
         event.target.classList.contains("callout-overlay") ||
         event.target.classList.contains("explorer-hint"))) {
        closePartModal();
    }
});


function drawCallout() {
    if (!activeHotspot || !partsViewer.classList.contains("callout-active")) {
        return;
    }

    updateDetailCrop(activeHotspot);
    const stage = partsViewer.getBoundingClientRect();
    const marker = activeHotspot.getBoundingClientRect();
    const panel = detailPanel.getBoundingClientRect();
    const scaleX = 1000 / stage.width;
    const scaleY = 600 / stage.height;
    const x1 = ((marker.left + marker.width / 2 - stage.left) * scaleX);
    const y1 = ((marker.top + marker.height / 2 - stage.top) * scaleY);
    const x2 = ((panel.left + panel.width / 2 - stage.left) * scaleX);
    const y2 = ((panel.top + panel.height / 2 - stage.top) * scaleY);

    document.getElementById("calloutLine").setAttribute("x1", x1);
    document.getElementById("calloutLine").setAttribute("y1", y1);
    document.getElementById("calloutLine").setAttribute("x2", x2);
    document.getElementById("calloutLine").setAttribute("y2", y2);
    document.getElementById("calloutDot").setAttribute("cx", x1);
    document.getElementById("calloutDot").setAttribute("cy", y1);
}

function updateDetailCrop(hotspot) {
    if (!hotspot || !detailCropImage || !partsScooter.naturalWidth ||
        !partsScooter.naturalHeight || !detailCropImage.offsetWidth) {
        return;
    }

    const stageWidth = vehicleCanvas.offsetWidth;
    const stageHeight = vehicleCanvas.offsetHeight;
    const targetX = hotspot.offsetLeft + hotspot.offsetWidth / 2;
    const targetY = hotspot.offsetTop + hotspot.offsetHeight / 2;
    const imageBoxLeft = stageWidth * .02;
    const imageBoxTop = stageHeight * .03;
    const imageBoxWidth = stageWidth * .96;
    const imageBoxHeight = stageHeight * .94;
    const imageScale = Math.min(
        imageBoxWidth / partsScooter.naturalWidth,
        imageBoxHeight / partsScooter.naturalHeight
    );
    const displayedWidth = partsScooter.naturalWidth * imageScale;
    const displayedHeight = partsScooter.naturalHeight * imageScale;
    const displayedLeft = imageBoxLeft + (imageBoxWidth - displayedWidth) / 2;
    const displayedTop = imageBoxTop + (imageBoxHeight - displayedHeight) / 2;
    const focusX = Math.max(0, Math.min(1, (targetX - displayedLeft) / displayedWidth));
    const focusY = Math.max(0, Math.min(1, (targetY - displayedTop) / displayedHeight));
    const cropWidth = detailCropImage.offsetWidth;
    const cropHeight = detailCropImage.offsetHeight;
    const cropFit = Math.min(
        cropWidth / detailCropImage.naturalWidth,
        cropHeight / detailCropImage.naturalHeight
    );
    const cropContentWidth = detailCropImage.naturalWidth * cropFit;
    const cropContentHeight = detailCropImage.naturalHeight * cropFit;
    const cropContentLeft = (cropWidth - cropContentWidth) / 2;
    const cropContentTop = (cropHeight - cropContentHeight) / 2;
    const cropScale = window.matchMedia("(max-width: 700px)").matches ? 2.6 : 2.9;
    const cropFocusX = cropContentLeft + focusX * cropContentWidth;
    const cropFocusY = cropContentTop + focusY * cropContentHeight;
    detailCropImage.style.transform =
        `translate(${cropWidth / 2 - cropFocusX * cropScale}px, ${cropHeight / 2 - cropFocusY * cropScale}px) scale(${cropScale})`;
}

detailCropImage.addEventListener("load", () => {
    if (activeHotspot) {
        updateDetailCrop(activeHotspot);
    }
});

partsScooter.addEventListener("load", () => {
    if (activeHotspot) {
        updateDetailCrop(activeHotspot);
    }
});


document.getElementById("closeModal").addEventListener("click", closePartModal);
window.addEventListener("resize", drawCallout);

function closePartModal() {
    if (!partsViewer || !detailPanel) {
        return;
    }

    partsViewer.classList.remove("is-focused", "callout-active");
    vehicleCanvas.style.transform = "";
    detailPanel.setAttribute("aria-hidden", "true");
    document.getElementById("closeModal").tabIndex = -1;
    document.body.classList.remove("detail-open");
    document.querySelectorAll(".hotspot").forEach(button => {
        button.classList.remove("is-selected");
    });

    if (activeHotspot) {
        activeHotspot.focus({ preventScroll: true });
    }
    activeHotspot = null;
    scheduleGalleryRotation(8000);
}


/* =====================================================
   BATTERY ANIMATION
===================================================== */

function startBatteryAnimation() {
    const fill = document.getElementById("batteryAnimationFill");
    const value = document.getElementById("batteryPercent");
    value.textContent = variants[selectedVariant].battery;
    fill.style.height = "0%";
    fill.style.backgroundColor = "hsl(0 78% 54%)";

    const started = performance.now();
    const frame = now => {
        const progress = Math.min(1, (now - started) / 2900);
        fill.style.height = `${progress * 100}%`;
        fill.style.backgroundColor = `hsl(${Math.round(progress * 120)} 78% 52%)`;
        if (progress < 1) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
}


/* =====================================================
   START BATTERY WHEN SECTION IS VISIBLE
===================================================== */

const batterySection =
    document.querySelector(".battery-section");


const observer =
    new IntersectionObserver(entries => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                startBatteryAnimation();

                observer.disconnect();

            }

        });

    }, {
        threshold: .3
    });


observer.observe(batterySection);


/* =====================================================
   COMPARISON TABLE
===================================================== */

const compareBody =
    document.getElementById("compareBody");

const compareHeader =
    document.getElementById("compareHeader");


const comparisonRows = [

    {
        label: "Top Speed",
        key: "speed"
    },

    {
        label: "Range",
        key: "range"
    },

    {
        label: "Battery",
        key: "battery"
    },

    {
        label: "Motor",
        key: "motor"
    },

    {
        label: "Load Capacity",
        key: "load"
    },

    {
        label: "Gradeability",
        key: "gradeability"
    },

    {
        label: "Charging Time",
        key: "charging"
    },

    {
        label: "Front Brake",
        key: "frontBrake"
    },

    {
        label: "Smart BMS",
        key: "bms"
    },

    {
        label: "Connectivity",
        key: "connectivity"
    }

];


function renderComparison() {

    const checked = [...document.querySelectorAll(".compare-check")]
            .filter(input => input.checked)
            .map(input => input.value);


    compareHeader.innerHTML =
        "<th>FEATURE</th>";


    compareBody.innerHTML = "";


    checked.forEach(id => {

        const variant =
            variants[id];


        const th =
            document.createElement("th");

        th.textContent =
            variant.name;

        compareHeader.appendChild(th);

    });


    comparisonRows.forEach(row => {

        const tr =
            document.createElement("tr");


        const featureCell =
            document.createElement("td");

        featureCell.textContent =
            row.label;


        tr.appendChild(featureCell);


        checked.forEach(id => {

            const td =
                document.createElement("td");

            td.textContent =
                (row.key === "range" ? variants[id].officialRange : variants[id][row.key]) || "—";


            tr.appendChild(td);

        });


        compareBody.appendChild(tr);

    });

}


document.querySelectorAll(
    ".compare-check"
).forEach(check => {

    check.addEventListener(
        "change",
        renderComparison
    );

});


/* =====================================================
   IMAGE ERROR HANDLING
===================================================== */

document.querySelectorAll("img")
    .forEach(img => {

        img.addEventListener("load", () => {
            delete img.dataset.fallbackAttempted;
        });

        img.addEventListener("error", () => {
            const currentFile = new URL(img.src, document.baseURI).pathname;
            if (currentFile.endsWith("/red.webp") || img.dataset.fallbackAttempted) {
                img.hidden = true;
                return;
            }
            img.dataset.fallbackAttempted = "true";
            img.src = new URL("red.webp", document.baseURI).href;

        });

    });


/* =====================================================
   INITIALIZE
===================================================== */

renderVariants();

renderComparison();

updateVariant("7g");


/* =====================================================
   ESC KEY
===================================================== */

document.addEventListener("keydown", event => {

    if (event.key === "Escape") {

        if (partsViewer.classList.contains("is-focused")) {
            closePartModal();
        }
        navMenu.classList.remove("open");
        menuButton.setAttribute("aria-expanded", "false");

    }

    if (event.key === "Tab" && partsViewer.classList.contains("is-focused")) {
        const closeButton = document.getElementById("closeModal");
        event.preventDefault();
        closeButton.focus();
    }

});