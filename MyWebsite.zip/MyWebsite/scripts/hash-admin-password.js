const crypto = require("node:crypto");

if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== "function") {
    console.error("Run this command in an interactive terminal so the password can be entered privately.");
    process.exit(1);
}

process.stdout.write("Enter the new admin password (hidden): ");
process.stdin.setRawMode(true);
process.stdin.setEncoding("utf8");
process.stdin.resume();

let password = "";
process.stdin.on("data", character => {
    if (character === "\u0003") {
        process.stdout.write("\nCancelled.\n");
        process.exit(1);
    }
    if (character === "\r" || character === "\n") {
        process.stdin.setRawMode(false);
        process.stdin.pause();
        process.stdout.write("\n");
        if (password.length < 12) {
            password = "";
            console.error("Use an admin password of at least 12 characters.");
            process.exitCode = 1;
            return;
        }
        const salt = crypto.randomBytes(16);
        const key = crypto.scryptSync(password, salt, 64);
        process.stdout.write(`SHOWROOM_ADMIN_PASSWORD_HASH=scrypt$${salt.toString("hex")}$${key.toString("hex")}\n`);
        password = "";
        return;
    }
    if (character === "\u007f" || character === "\b") {
        password = password.slice(0, -1);
        return;
    }
    password += character;
});
