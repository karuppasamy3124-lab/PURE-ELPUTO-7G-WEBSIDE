"""Local-only web server and SQLite visitor store for the PURE EV showroom."""

import argparse
import base64
import binascii
import hmac
import json
import os
import re
import secrets
import sqlite3
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit


PROJECT_DIR = Path(__file__).resolve().parent
ADMIN_PAGE = PROJECT_DIR / "admin.html"
ADMIN_USER = "admin"
PHONE_PATTERN = re.compile(r"^[6-9][0-9]{9}$")
NAME_PATTERN = re.compile(r"^[^\x00-\x1f\x7f]{2,80}$")
MAX_BODY_SIZE = 4096
MAX_ADMIN_ROWS = 500

LOCAL_DATA = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
DATABASE_DIR = LOCAL_DATA / "PureEVShowroom"
DATABASE_PATH = DATABASE_DIR / "visitors.sqlite3"


def initialize_database():
    DATABASE_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DATABASE_PATH, timeout=10) as connection:
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS visitors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            "CREATE INDEX IF NOT EXISTS visitors_created_at "
            "ON visitors(created_at DESC)"
        )


class ShowroomHandler(SimpleHTTPRequestHandler):
    server_version = "PUREEVShowroom/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(PROJECT_DIR), **kwargs)

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        origin = self.allowed_local_origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        super().end_headers()

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def require_admin(self):
        expected = f"{ADMIN_USER}:{self.server.admin_password}"
        header = self.headers.get("Authorization", "")
        scheme, separator, encoded = header.partition(" ")
        if separator and scheme.lower() == "basic":
            try:
                supplied = base64.b64decode(encoded, validate=True).decode("utf-8")
            except (binascii.Error, UnicodeDecodeError):
                supplied = ""
            if hmac.compare_digest(supplied, expected):
                return True

        self.send_response(401)
        self.send_header(
            "WWW-Authenticate",
            'Basic realm="PURE EV local admin", charset="UTF-8"',
        )
        self.send_header("Content-Length", "0")
        self.end_headers()
        return False

    def allowed_local_origin(self):
        origin = self.headers.get("Origin", "")
        parsed = urlsplit(origin)
        try:
            port = parsed.port
        except ValueError:
            return ""
        if (parsed.scheme == "http" and
                parsed.hostname in {"127.0.0.1", "localhost"} and
                port is not None and
                parsed.username is None and
                parsed.password is None):
            return origin
        return ""

    def has_local_origin(self):
        return bool(self.allowed_local_origin())

    def read_json_body(self):
        raw_length = self.headers.get("Content-Length", "")
        if not raw_length.isdecimal():
            raise ValueError("A valid request size is required.")
        content_length = int(raw_length)
        if content_length < 1 or content_length > MAX_BODY_SIZE:
            raise ValueError("The request is too large or empty.")
        if self.headers.get_content_type() != "application/json":
            raise ValueError("Send the entry as JSON.")
        body = self.rfile.read(content_length)
        return json.loads(body.decode("utf-8"))

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/":
            self.path = "/Taamsi.html"
            return super().do_GET()
        if path == "/api/health":
            self.send_json(200, {"ok": True, "admin": "/admin"})
            return
        if path in {"/admin/", "/admin.html"}:
            self.send_redirect("/admin")
            return
        if path == "/admin":
            if not self.require_admin():
                return
            try:
                body = ADMIN_PAGE.read_bytes()
            except OSError:
                self.log_error("Could not read the admin dashboard file.")
                self.send_error(500, "Admin dashboard is missing or unreadable.")
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/api/admin/visitors":
            if not self.require_admin():
                return
            try:
                with sqlite3.connect(DATABASE_PATH, timeout=10) as connection:
                    connection.row_factory = sqlite3.Row
                    records = connection.execute(
                        """
                        SELECT id, name, phone, created_at
                        FROM visitors
                        ORDER BY id DESC
                        LIMIT ?
                        """,
                        (MAX_ADMIN_ROWS,),
                    ).fetchall()
                self.send_json(
                    200,
                    {
                        "records": [dict(record) for record in records],
                        "limit": MAX_ADMIN_ROWS,
                    },
                )
            except sqlite3.Error:
                self.log_error("Could not read visitor records from SQLite.")
                self.send_json(500, {"error": "Visitor records could not be read."})
            return
        return super().do_GET()

    def do_POST(self):
        if urlsplit(self.path).path != "/api/visitors":
            self.send_json(404, {"error": "Not found."})
            return
        if not self.has_local_origin():
            self.send_json(403, {"error": "This request origin is not allowed."})
            return

        try:
            payload = self.read_json_body()
            if not isinstance(payload, dict):
                raise ValueError("Entry details must be provided.")
            if payload.get("consent") is not True:
                raise ValueError("Consent is required before details can be saved.")
            name = payload.get("name")
            phone = payload.get("phone")
            if not isinstance(name, str) or not NAME_PATTERN.fullmatch(name.strip()):
                raise ValueError("Enter a name between 2 and 80 characters.")
            if not isinstance(phone, str) or not PHONE_PATTERN.fullmatch(phone.strip()):
                raise ValueError("Enter a valid 10-digit Indian mobile number.")
            with sqlite3.connect(DATABASE_PATH, timeout=10) as connection:
                connection.execute(
                    """
                    INSERT INTO visitors (name, phone, created_at)
                    VALUES (?, ?, ?)
                    """,
                    (
                        name.strip(),
                        phone.strip(),
                        datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    ),
                )
            self.send_json(201, {"saved": True})
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
            self.send_json(400, {"error": str(error)})
        except sqlite3.Error:
            self.log_error("Could not save showroom visitor details to SQLite.")
            self.send_json(500, {"error": "Your details could not be saved. Please try again."})

    def do_OPTIONS(self):
        if urlsplit(self.path).path != "/api/visitors" or not self.has_local_origin():
            self.send_json(403, {"error": "This request origin is not allowed."})
            return
        self.send_response(204)
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_DELETE(self):
        if urlsplit(self.path).path != "/api/admin/visitors":
            self.send_json(404, {"error": "Not found."})
            return
        if not self.require_admin():
            return
        if not self.has_local_origin():
            self.send_json(403, {"error": "This request origin is not allowed."})
            return

        try:
            payload = self.read_json_body()
            record_id = payload.get("id") if isinstance(payload, dict) else None
            if not isinstance(record_id, int) or record_id < 1:
                raise ValueError("A valid record id is required.")
            with sqlite3.connect(DATABASE_PATH, timeout=10) as connection:
                cursor = connection.execute(
                    "DELETE FROM visitors WHERE id = ?",
                    (record_id,),
                )
            if cursor.rowcount == 0:
                self.send_json(404, {"error": "That record was not found."})
            else:
                self.send_json(200, {"deleted": True})
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
            self.send_json(400, {"error": str(error)})
        except sqlite3.Error:
            self.log_error("Could not delete showroom visitor record from SQLite.")
            self.send_json(500, {"error": "The record could not be deleted."})


def main():
    parser = argparse.ArgumentParser(
        description="Run the PURE EV ePluto 7G showroom locally."
    )
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("--port must be between 1 and 65535")

    admin_password = os.environ.get("SHOWROOM_ADMIN_PASSWORD")
    if admin_password and len(admin_password) < 14:
        parser.error("SHOWROOM_ADMIN_PASSWORD must be at least 14 characters.")
    generated_password = not admin_password
    if generated_password:
        admin_password = secrets.token_urlsafe(24)

    initialize_database()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), ShowroomHandler)
    server.admin_password = admin_password
    print(f"PURE EV showroom: http://127.0.0.1:{args.port}/")
    print(f"Admin dashboard:  http://127.0.0.1:{args.port}/admin")
    print(f"SQLite records:   {DATABASE_PATH}")
    if generated_password:
        print("Generated local admin password (save it; it changes on restart):")
        print(admin_password)
        print(
            "Set SHOWROOM_ADMIN_PASSWORD to a private 14+ character value "
            "to keep it stable between starts."
        )
    print("Server is bound to 127.0.0.1; it is not available to other devices.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping the local showroom.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
