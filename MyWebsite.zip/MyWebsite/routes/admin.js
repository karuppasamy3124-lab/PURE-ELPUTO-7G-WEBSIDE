const express = require("express");
const { rateLimit } = require("express-rate-limit");

const router = express.Router();
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 8,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { error: "Too many sign-in attempts. Wait 15 minutes and try again." }
});

function isAdmin(req, res, next) {
    if (req.session.admin === true) return next();
    return res.status(401).json({ error: "Admin sign-in is required." });
}

router.post("/login", loginLimiter, async (req, res, next) => {
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    try {
        const isValid = await req.app.locals.verifyAdminPassword(password);
        if (!isValid) {
            return res.status(401).json({ error: "The admin password is incorrect." });
        }
        req.session.regenerate(error => {
            if (error) return next(error);
            req.session.admin = true;
            req.session.save(saveError => {
                if (saveError) return next(saveError);
                return res.json({ authenticated: true });
            });
        });
    } catch (error) {
        return next(error);
    }
});

router.post("/logout", isAdmin, (req, res, next) => {
    req.session.destroy(error => {
        if (error) return next(error);
        res.clearCookie("pureev.admin", {
            httpOnly: true,
            path: "/",
            sameSite: "strict",
            secure: req.secure
        });
        return res.status(204).end();
    });
});

router.get("/me", (req, res) => {
    return res.json({ authenticated: req.session.admin === true });
});

router.get("/analytics", isAdmin, (req, res) => {
    const from = typeof req.query.from === "string" ? req.query.from : "";
    const to = typeof req.query.to === "string" ? req.query.to : "";
    const validDate = value => {
        if (!value) return true;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
        const [year, month, day] = value.split("-").map(Number);
        const parsed = new Date(Date.UTC(year, month - 1, day));
        return parsed.getUTCFullYear() === year &&
            parsed.getUTCMonth() === month - 1 &&
            parsed.getUTCDate() === day;
    };
    if (!validDate(from) || !validDate(to) || (from && to && from > to)) {
        return res.status(400).json({ error: "Choose a valid date range." });
    }

    try {
        const database = req.app.locals.database;
        const today = new Date().toISOString().slice(0, 10);
        const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
        const totalVisitors = database.prepare("SELECT COUNT(*) AS count FROM visitors").get().count;
        const todayVisitors = database.prepare(
            "SELECT COUNT(*) AS count FROM visitors WHERE login_date = ?"
        ).get(today).count;
        const yesterdayVisitors = database.prepare(
            "SELECT COUNT(*) AS count FROM visitors WHERE login_date = ?"
        ).get(yesterday).count;
        const mostViewed = database.prepare(`
            SELECT variant, COUNT(*) AS count
            FROM visitors GROUP BY variant
            ORDER BY count DESC, variant ASC LIMIT 1
        `).get();

        const conditions = [];
        const values = [];
        if (from) {
            conditions.push("login_date >= ?");
            values.push(from);
        }
        if (to) {
            conditions.push("login_date <= ?");
            values.push(to);
        }
        const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
        const dailyVisits = database.prepare(`
            SELECT login_date AS date, COUNT(*) AS visitors
            FROM visitors ${where}
            GROUP BY login_date ORDER BY login_date DESC LIMIT 30
        `).all(...values);

        return res.json({
            totalVisitors,
            todayVisitors,
            yesterdayVisitors,
            totalLogins: totalVisitors,
            mostViewedVariant: mostViewed?.variant || "—",
            dailyVisits
        });
    } catch (error) {
        console.error("Could not load visitor analytics:", error);
        return res.status(500).json({ error: "Visitor analytics could not be loaded." });
    }
});

module.exports = router;
