const crypto = require("node:crypto");
const express = require("express");

const router = express.Router();
const PHONE_PATTERN = /^[6-9]\d{9}$/;
const NAME_PATTERN = /^[\p{L}\p{M} .'-]{2,80}$/u;
const VARIANTS = new Set(["7g", "pro", "max", "cx"]);
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function isValidDate(value) {
    if (!DATE_PATTERN.test(value)) return false;
    const [year, month, day] = value.split("-").map(Number);
    const parsed = new Date(Date.UTC(year, month - 1, day));
    return parsed.getUTCFullYear() === year &&
        parsed.getUTCMonth() === month - 1 &&
        parsed.getUTCDate() === day;
}

function requireAdmin(req, res, next) {
    if (req.session.admin === true) {
        return next();
    }
    return res.status(401).json({ error: "Admin sign-in is required." });
}

function deviceFromUserAgent(userAgent) {
    if (/tablet|ipad/i.test(userAgent)) return "Tablet";
    if (/mobile|android|iphone|ipod/i.test(userAgent)) return "Mobile";
    return "Desktop";
}

function normalizedRecord(payload) {
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
        return { error: "Visitor details are required." };
    }

    const name = typeof payload.name === "string" ? payload.name.trim() : "";
    const phone = typeof payload.phone === "string" ? payload.phone.trim() : "";
    const variant = typeof payload.variant === "string" ? payload.variant : "";
    const loginDate = typeof payload.loginDate === "string" ? payload.loginDate : "";
    const loginTime = typeof payload.loginTime === "string" ? payload.loginTime : "";
    const device = typeof payload.device === "string" ? payload.device.trim() : "";

    if (!NAME_PATTERN.test(name)) {
        return { error: "Name must be 2–80 letters and may include spaces, apostrophes, periods or hyphens." };
    }
    if (!PHONE_PATTERN.test(phone)) {
        return { error: "Enter a valid 10-digit Indian mobile number." };
    }
    if (!VARIANTS.has(variant)) {
        return { error: "Select a valid ePluto variant." };
    }
    if (loginDate && !isValidDate(loginDate)) {
        return { error: "Login date must use YYYY-MM-DD format." };
    }
    if (loginTime && !/^\d{2}:\d{2}(:\d{2})?$/.test(loginTime)) {
        return { error: "Login time must use HH:MM format." };
    }

    return {
        record: {
            name,
            phone,
            variant,
            loginDate,
            loginTime,
            device: device.slice(0, 40)
        }
    };
}

function createVisitor(req, record) {
    const now = new Date();
    const timestamp = now.toISOString();
    const userAgent = String(req.get("user-agent") || "").slice(0, 512);
    const date = record.loginDate || timestamp.slice(0, 10);
    const time = record.loginTime || timestamp.slice(11, 19);
    const device = record.device || deviceFromUserAgent(userAgent);
    const visitId = crypto.randomUUID();
    const sessionFingerprint = crypto
        .createHash("sha256")
        .update(req.sessionID)
        .digest("hex");

    const result = req.app.locals.database.prepare(`
        INSERT INTO visitors (
            name, phone, variant, login_date, login_time, device, user_agent,
            visit_id, session_fingerprint, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
        record.name,
        record.phone,
        record.variant,
        date,
        time,
        device,
        userAgent,
        visitId,
        sessionFingerprint,
        timestamp,
        timestamp
    );

    return { id: Number(result.lastInsertRowid), visitId };
}

function dateFilters(req, res, next) {
    const { from, to } = req.query;
    if ((from && !isValidDate(from)) || (to && !isValidDate(to))) {
        return res.status(400).json({ error: "Dates must use YYYY-MM-DD format." });
    }
    if (from && to && from > to) {
        return res.status(400).json({ error: "Start date must be on or before end date." });
    }
    return next();
}

router.post("/", (req, res) => {
    const normalized = normalizedRecord(req.body);
    if (normalized.error) {
        return res.status(400).json({ error: normalized.error });
    }
    try {
        return res.status(201).json(createVisitor(req, normalized.record));
    } catch (error) {
        console.error("Could not save visitor record:", error);
        return res.status(500).json({ error: "Visitor details could not be saved." });
    }
});

router.get("/", requireAdmin, dateFilters, (req, res) => {
    try {
        const conditions = [];
        const values = [];
        if (req.query.from) {
            conditions.push("login_date >= ?");
            values.push(req.query.from);
        }
        if (req.query.to) {
            conditions.push("login_date <= ?");
            values.push(req.query.to);
        }
        const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
        const records = req.app.locals.database.prepare(`
            SELECT id, name, phone, variant, login_date AS loginDate,
                   login_time AS loginTime, device, created_at AS createdAt,
                   updated_at AS updatedAt
            FROM visitors ${where}
            ORDER BY login_date DESC, login_time DESC, id DESC
            LIMIT 1000
        `).all(...values);
        return res.json({ records, limit: 1000 });
    } catch (error) {
        console.error("Could not read visitor records:", error);
        return res.status(500).json({ error: "Visitor records could not be read." });
    }
});

router.get("/:id", requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) {
        return res.status(400).json({ error: "Visitor ID is invalid." });
    }
    try {
        const record = req.app.locals.database.prepare(`
            SELECT id, name, phone, variant, login_date AS loginDate,
                   login_time AS loginTime, device, created_at AS createdAt,
                   updated_at AS updatedAt
            FROM visitors WHERE id = ?
        `).get(id);
        if (!record) return res.status(404).json({ error: "Visitor record was not found." });
        return res.json({ record });
    } catch (error) {
        console.error("Could not read visitor record:", error);
        return res.status(500).json({ error: "Visitor record could not be read." });
    }
});

router.put("/:id", requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) {
        return res.status(400).json({ error: "Visitor ID is invalid." });
    }
    const normalized = normalizedRecord(req.body);
    if (normalized.error) {
        return res.status(400).json({ error: normalized.error });
    }

    const record = normalized.record;
    try {
        const result = req.app.locals.database.prepare(`
            UPDATE visitors
            SET name = ?, phone = ?, variant = ?, login_date = ?, login_time = ?,
                device = ?, updated_at = ?
            WHERE id = ?
        `).run(
            record.name,
            record.phone,
            record.variant,
            record.loginDate || new Date().toISOString().slice(0, 10),
            record.loginTime || new Date().toISOString().slice(11, 19),
            record.device || "Unknown",
            new Date().toISOString(),
            id
        );
        if (result.changes === 0) return res.status(404).json({ error: "Visitor record was not found." });
        return res.json({ updated: true });
    } catch (error) {
        console.error("Could not update visitor record:", error);
        return res.status(500).json({ error: "Visitor record could not be updated." });
    }
});

router.delete("/:id", requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) {
        return res.status(400).json({ error: "Visitor ID is invalid." });
    }
    try {
        const result = req.app.locals.database.prepare(
            "DELETE FROM visitors WHERE id = ?"
        ).run(id);
        if (result.changes === 0) return res.status(404).json({ error: "Visitor record was not found." });
        return res.status(204).end();
    } catch (error) {
        console.error("Could not delete visitor record:", error);
        return res.status(500).json({ error: "Visitor record could not be deleted." });
    }
});

module.exports = router;
