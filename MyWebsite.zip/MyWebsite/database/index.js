const fs = require("node:fs");
const path = require("node:path");
const Database = require("better-sqlite3");

const databaseDirectory = __dirname;
fs.mkdirSync(databaseDirectory, { recursive: true });

const database = new Database(path.join(databaseDirectory, "visitors.sqlite"));
database.pragma("journal_mode = WAL");
database.pragma("foreign_keys = ON");
database.exec(`
    CREATE TABLE IF NOT EXISTS visitors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        variant TEXT NOT NULL,
        login_date TEXT NOT NULL,
        login_time TEXT NOT NULL,
        device TEXT NOT NULL,
        user_agent TEXT NOT NULL,
        visit_id TEXT NOT NULL,
        session_fingerprint TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS visitors_login_date ON visitors(login_date);
    CREATE INDEX IF NOT EXISTS visitors_variant ON visitors(variant);
    CREATE INDEX IF NOT EXISTS visitors_created_at ON visitors(created_at DESC);
`);

module.exports = database;
