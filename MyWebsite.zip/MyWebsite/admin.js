const loginView = document.getElementById("loginView");
const dashboardView = document.getElementById("dashboardView");
const loginForm = document.getElementById("loginForm");
const loginStatus = document.getElementById("loginStatus");
const adminStatus = document.getElementById("adminStatus");
const rowsElement = document.getElementById("recordRows");
const searchInput = document.getElementById("recordSearch");
const countElement = document.getElementById("recordCount");
const dialog = document.getElementById("visitorDialog");
const visitorForm = document.getElementById("visitorForm");

let records = [];
let currentFilter = "today";
let customRange = null;
let editingId = null;

const variantNames = {
    "7g": "ePluto 7G",
    pro: "ePluto 7G PRO",
    max: "ePluto 7G MAX",
    cx: "ePluto 7G CX"
};

function utcDate(date) {
    return date.toISOString().slice(0, 10);
}

function dateRange(period) {
    const today = new Date();
    const end = utcDate(today);
    const start = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
    if (period === "yesterday") {
        start.setUTCDate(start.getUTCDate() - 1);
        return { from: utcDate(start), to: utcDate(start) };
    }
    if (period === "7" || period === "30") {
        start.setUTCDate(start.getUTCDate() - Number(period) + 1);
        return { from: utcDate(start), to: end };
    }
    if (period === "custom") return customRange;
    return { from: end, to: end };
}

function setStatus(element, message, isError = false) {
    element.textContent = message;
    element.classList.toggle("error", isError);
}

async function api(url, options = {}) {
    const response = await fetch(url, {
        credentials: "same-origin",
        ...options,
        headers: {
            ...(options.body ? { "Content-Type": "application/json" } : {}),
            ...options.headers
        }
    });
    if (!response.ok) {
        const result = await response.json().catch(() => ({}));
        throw new Error(result.error || `Request failed (${response.status}).`);
    }
    return response.status === 204 ? null : response.json();
}

function displayDate(date) {
    if (!date) return "—";
    const [year, month, day] = date.split("-").map(Number);
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit", month: "short", year: "numeric", timeZone: "UTC"
    }).format(new Date(Date.UTC(year, month - 1, day)));
}

function renderRecords() {
    const search = searchInput.value.trim().toLowerCase();
    const filtered = records.filter(record =>
        `${record.name} ${record.phone} ${record.variant}`.toLowerCase().includes(search)
    );
    rowsElement.replaceChildren();
    countElement.textContent = `${filtered.length} of ${records.length} records`;

    if (!filtered.length) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");
        cell.colSpan = 8;
        cell.className = "empty-row";
        cell.textContent = records.length ? "No visitor records match your search." : "No visitor records for this date range.";
        row.appendChild(cell);
        rowsElement.appendChild(row);
        return;
    }

    filtered.forEach(record => {
        const row = document.createElement("tr");
        [
            String(record.id).padStart(3, "0"),
            record.name,
            record.phone,
            variantNames[record.variant] || record.variant,
            displayDate(record.loginDate),
            record.loginTime,
            record.device
        ].forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        const actionCell = document.createElement("td");
        const actions = document.createElement("div");
        actions.className = "row-actions";
        const edit = document.createElement("button");
        edit.className = "button button-quiet";
        edit.type = "button";
        edit.textContent = "Edit";
        edit.setAttribute("aria-label", `Edit visitor ${record.name}`);
        edit.addEventListener("click", () => openVisitorDialog(record));
        const remove = document.createElement("button");
        remove.className = "button button-quiet delete-button";
        remove.type = "button";
        remove.textContent = "Delete";
        remove.setAttribute("aria-label", `Delete visitor ${record.name}`);
        remove.addEventListener("click", () => deleteVisitor(record));
        actions.append(edit, remove);
        actionCell.appendChild(actions);
        row.appendChild(actionCell);
        rowsElement.appendChild(row);
    });
}

function renderDailyChart(days) {
    const chart = document.getElementById("dailyChart");
    chart.replaceChildren();
    if (!days.length) {
        const empty = document.createElement("p");
        empty.className = "muted";
        empty.textContent = "No visits in this date range.";
        chart.appendChild(empty);
        return;
    }

    const maximum = Math.max(...days.map(day => day.visitors), 1);
    days.forEach(day => {
        const item = document.createElement("div");
        item.className = "daily-item";
        const value = document.createElement("span");
        value.className = "daily-value";
        value.textContent = String(day.visitors);
        const track = document.createElement("span");
        track.className = "daily-bar-track";
        const bar = document.createElement("span");
        bar.className = "daily-bar";
        bar.style.height = `${Math.max(5, (day.visitors / maximum) * 100)}%`;
        bar.setAttribute("aria-label", `${day.visitors} visitors`);
        track.appendChild(bar);
        const label = document.createElement("span");
        label.textContent = displayDate(day.date);
        item.append(value, track, label);
        chart.appendChild(item);
    });
}

async function loadDashboard() {
    setStatus(adminStatus, "Loading visitor records…");
    const range = dateRange(currentFilter);
    if (currentFilter === "custom" && !range) {
        setStatus(adminStatus, "Choose a custom date range and apply it first.");
        return;
    }
    const query = range ? `?from=${encodeURIComponent(range.from)}&to=${encodeURIComponent(range.to)}` : "";
    try {
        const [visitorResult, analytics] = await Promise.all([
            api(`/api/visitors${query}`),
            api(`/api/admin/analytics${query}`)
        ]);
        records = visitorResult.records;
        document.getElementById("totalVisitors").textContent = analytics.totalVisitors;
        document.getElementById("todayVisitors").textContent = analytics.todayVisitors;
        document.getElementById("totalLogins").textContent = analytics.totalLogins;
        document.getElementById("mostViewedVariant").textContent =
            variantNames[analytics.mostViewedVariant] || analytics.mostViewedVariant;
        renderDailyChart(analytics.dailyVisits);
        renderRecords();
        setStatus(adminStatus, "");
    } catch (error) {
        setStatus(adminStatus, error.message, true);
    }
}

async function showDashboard() {
    loginView.hidden = true;
    dashboardView.hidden = false;
    await loadDashboard();
}

async function checkSession() {
    try {
        const result = await api("/api/admin/me");
        if (result.authenticated) await showDashboard();
    } catch (error) {
        setStatus(loginStatus, error.message, true);
    }
}

function openVisitorDialog(record = null) {
    editingId = record ? record.id : null;
    document.getElementById("visitorDialogTitle").textContent = record ? "Edit visitor" : "Add visitor";
    document.getElementById("visitorId").value = record ? String(record.id) : "";
    document.getElementById("visitorName").value = record ? record.name : "";
    document.getElementById("visitorPhone").value = record ? record.phone : "";
    document.getElementById("visitorVariant").value = record ? record.variant : "7g";
    document.getElementById("visitorDate").value = record ? record.loginDate : utcDate(new Date());
    document.getElementById("visitorTime").value = record ? record.loginTime.slice(0, 5) : new Date().toISOString().slice(11, 16);
    document.getElementById("visitorDevice").value = record ? record.device : "Desktop";
    setStatus(document.getElementById("visitorFormStatus"), "");
    dialog.showModal();
    document.getElementById("visitorName").focus();
}

async function deleteVisitor(record) {
    if (!window.confirm(`Are you sure you want to delete visitor ${record.name}? This cannot be undone.`)) return;
    try {
        await api(`/api/visitors/${record.id}`, { method: "DELETE" });
        setStatus(adminStatus, "Visitor record deleted.");
        await loadDashboard();
    } catch (error) {
        setStatus(adminStatus, error.message, true);
    }
}

function exportCsv() {
    const headers = ["ID", "NAME", "PHONE", "VARIANT", "DATE", "TIME", "DEVICE"];
    const escapeCsv = value => {
        let text = String(value ?? "");
        if (/^[=+\-@]/.test(text)) text = `'${text}`;
        return `"${text.replace(/"/g, '""')}"`;
    };
    const lines = [headers, ...records.map(record => [
        record.id,
        record.name,
        record.phone,
        variantNames[record.variant] || record.variant,
        record.loginDate,
        record.loginTime,
        record.device
    ])].map(row => row.map(escapeCsv).join(","));
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([lines.join("\r\n")], { type: "text/csv;charset=utf-8" }));
    link.download = "pure-ev-visitors.csv";
    link.click();
    URL.revokeObjectURL(link.href);
}

loginForm.addEventListener("submit", async event => {
    event.preventDefault();
    const submit = loginForm.querySelector('button[type="submit"]');
    submit.disabled = true;
    setStatus(loginStatus, "Signing in…");
    try {
        await api("/api/admin/login", {
            method: "POST",
            body: JSON.stringify({ password: document.getElementById("adminPassword").value })
        });
        loginForm.reset();
        await showDashboard();
    } catch (error) {
        setStatus(loginStatus, error.message, true);
    } finally {
        submit.disabled = false;
    }
});

document.getElementById("logoutButton").addEventListener("click", async () => {
    try {
        await api("/api/admin/logout", { method: "POST" });
        dashboardView.hidden = true;
        loginView.hidden = false;
        document.getElementById("adminPassword").focus();
    } catch (error) {
        setStatus(adminStatus, error.message, true);
    }
});

document.querySelectorAll(".date-button").forEach(button => {
    button.addEventListener("click", () => {
        document.querySelectorAll(".date-button").forEach(item => item.classList.remove("active"));
        button.classList.add("active");
        currentFilter = button.dataset.period;
        const customForm = document.getElementById("customDateForm");
        customForm.hidden = currentFilter !== "custom";
        if (currentFilter !== "custom") {
            customRange = null;
            loadDashboard();
        }
    });
});

document.getElementById("customDateForm").addEventListener("submit", event => {
    event.preventDefault();
    customRange = {
        from: document.getElementById("dateFrom").value,
        to: document.getElementById("dateTo").value
    };
    if (customRange.from > customRange.to) {
        setStatus(adminStatus, "Start date must be on or before end date.", true);
        return;
    }
    loadDashboard();
});

visitorForm.addEventListener("submit", async event => {
    event.preventDefault();
    const formStatus = document.getElementById("visitorFormStatus");
    const body = {
        name: document.getElementById("visitorName").value,
        phone: document.getElementById("visitorPhone").value,
        variant: document.getElementById("visitorVariant").value,
        loginDate: document.getElementById("visitorDate").value,
        loginTime: document.getElementById("visitorTime").value,
        device: document.getElementById("visitorDevice").value
    };
    const saveButton = visitorForm.querySelector('button[type="submit"]');
    saveButton.disabled = true;
    try {
        await api(editingId ? `/api/visitors/${editingId}` : "/api/visitors", {
            method: editingId ? "PUT" : "POST",
            body: JSON.stringify(body)
        });
        dialog.close();
        await loadDashboard();
        setStatus(adminStatus, editingId ? "Visitor record updated." : "Visitor record added.");
    } catch (error) {
        setStatus(formStatus, error.message, true);
    } finally {
        saveButton.disabled = false;
    }
});

document.getElementById("addVisitorButton").addEventListener("click", () => openVisitorDialog());
document.getElementById("closeVisitorDialog").addEventListener("click", () => dialog.close());
document.getElementById("cancelVisitorDialog").addEventListener("click", () => dialog.close());
document.getElementById("refreshRecords").addEventListener("click", loadDashboard);
document.getElementById("exportRecords").addEventListener("click", exportCsv);
searchInput.addEventListener("input", renderRecords);

checkSession();
