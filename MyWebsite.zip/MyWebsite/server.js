require("dotenv").config();

const crypto = require("node:crypto");
const path = require("node:path");
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const adminRoutes = require("./routes/admin");
const visitorRoutes = require("./routes/visitors");

const app = express();
const projectRoot = __dirname;
const port = Number(process.env.PORT || 8000);
const isProduction = process.env.NODE_ENV === "production";
const cookieName = "pureev.admin";
const localAdminPassword = process.env.LOCAL_ADMIN_PASSWORD || "TAAM2024";

function parseScryptHash(value) {
    const [scheme, saltHex, keyHex, extra] = String(value || "").split("$");
    if (scheme !== "scrypt" || extra !== undefined ||
        !/^[a-f\d]{32}$/i.test(saltHex || "") ||
        !/^[a-f\d]{128}$/i.test(keyHex || "")) {
        throw new Error("SHOWROOM_ADMIN_PASSWORD_HASH must be a scrypt hash from npm run hash-admin-password.");
    }
    return { salt: Buffer.from(saltHex, "hex"), key: Buffer.from(keyHex, "hex") };
}

function createScryptHash(password) {
    const salt = crypto.randomBytes(16);
    const key = crypto.scryptSync(password, salt, 64);
    return `scrypt$${salt.toString("hex")}$${key.toString("hex")}`;
}

if (isProduction && !process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET must be configured in production.");
}
if (isProduction && process.env.SESSION_SECRET.length < 32) {
    throw new Error("SESSION_SECRET must be at least 32 characters in production.");
}
if (isProduction && !process.env.SHOWROOM_ADMIN_PASSWORD_HASH) {
    throw new Error("SHOWROOM_ADMIN_PASSWORD_HASH must be configured in production.");
}

const adminHash = process.env.SHOWROOM_ADMIN_PASSWORD_HASH
    ? parseScryptHash(process.env.SHOWROOM_ADMIN_PASSWORD_HASH)
    : parseScryptHash(createScryptHash(process.env.SHOWROOM_ADMIN_PASSWORD || localAdminPassword));
const sessionSecret = process.env.SESSION_SECRET || crypto.randomBytes(48).toString("hex");
const database = require("./database");

app.disable("x-powered-by");
app.set("trust proxy", isProduction ? 1 : false);
app.locals.database = database;
app.locals.verifyAdminPassword = password => new Promise((resolve, reject) => {
    crypto.scrypt(password, adminHash.salt, adminHash.key.length, (error, derivedKey) => {
        if (error) return reject(error);
        return resolve(crypto.timingSafeEqual(derivedKey, adminHash.key));
    });
});

app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            baseUri: ["'self'"],
            connectSrc: ["'self'"],
            fontSrc: ["'self'", "data:"],
            formAction: ["'self'"],
            frameAncestors: ["'none'"],
            imgSrc: ["'self'", "data:"],
            objectSrc: ["'none'"],
            scriptSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"]
        }
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: "no-referrer" }
}));
app.use((req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    if (!["POST", "PUT", "DELETE"].includes(req.method)) return next();
    const origin = req.get("origin");
    if (!origin) return next();
    try {
        const parsedOrigin = new URL(origin);
        const expectedOrigin = `${req.protocol}://${req.get("host")}`;
        if (parsedOrigin.origin !== expectedOrigin) {
            return res.status(403).json({ error: "Cross-origin requests are not allowed." });
        }
    } catch {
        return res.status(403).json({ error: "The request origin is invalid." });
    }
    return next();
});
app.use(express.json({ limit: "12kb", strict: true }));
app.use(session({
    name: cookieName,
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        secure: isProduction,
        sameSite: "strict",
        maxAge: 8 * 60 * 60 * 1000
    }
}));

app.get("/", (req, res) => res.sendFile(path.join(projectRoot, "index.html")));
app.get("/index.html", (req, res) => res.sendFile(path.join(projectRoot, "index.html")));
app.get("/Taamsi.html", (req, res) => res.redirect(302, "/"));
app.get(["/admin", "/admin/"], (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    return res.sendFile(path.join(projectRoot, "admin.html"));
});
app.get("/admin.html", (req, res) => res.redirect(302, "/admin"));
app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use("/api/admin", adminRoutes);
app.use("/api/visitors", visitorRoutes);

const publicFiles = new Set([
    "admin.css",
    "admin.js",
    "css/main.css",
    "css/base/reset.css",
    "css/base/variables.css",
    "css/base/typography.css",
    "css/layout/container.css",
    "css/layout/navbar.css",
    "css/layout/responsive.css",
    "css/components/animations.css",
    "css/components/buttons.css",
    "css/components/cards.css",
    "css/components/forms.css",
    "css/components/modals.css",
    "css/sections/welcome.css",
    "css/sections/hero.css",
    "css/sections/variants.css",
    "css/sections/colours.css",
    "css/sections/gallery.css",
    "css/sections/scooter-explorer.css",
    "css/sections/specifications.css",
    "css/sections/range.css",
    "css/sections/battery.css",
    "css/sections/features.css",
    "css/sections/comparison.css",
    "css/sections/contact.css",
    "css/sections/footer.css",
    "js/core/app.js",
    "js/core/images.js",
    "js/core/navigation.js",
    "js/core/state.js",
    "js/core/storage.js",
    "js/data/colours.js",
    "js/data/scooter-parts.js",
    "js/data/variants.js",
    "js/components/animations.js",
    "js/sections/battery.js",
    "js/sections/colours.js",
    "js/sections/comparison.js",
    "js/sections/features.js",
    "js/sections/gallery.js",
    "js/sections/range.js",
    "js/sections/scooter-explorer.js",
    "js/sections/specifications.js",
    "js/sections/variants.js",
    "js/sections/welcome.js",
    "assets/images/colours/red.webp",
    "assets/images/colours/images.jpg",
    "assets/images/colours/images (1).jpg",
    "assets/images/variants/images (4).jpg",
    "assets/images/gallery/download.jpg",
    "assets/images/gallery/download (1).jpg",
    "assets/images/gallery/images (2).jpg",
    "assets/images/gallery/images (3).jpg"
]);
const servePublicFile = express.static(projectRoot, {
    dotfiles: "deny",
    fallthrough: false,
    index: false,
    maxAge: isProduction ? "1h" : 0,
    setHeaders(res) {
        res.setHeader("X-Content-Type-Options", "nosniff");
    }
});

app.use((req, res, next) => {
    if (req.method !== "GET") return res.sendStatus(404);
    let requestedFile;
    try {
        requestedFile = decodeURIComponent(req.path.slice(1));
    } catch {
        return res.status(400).send("Invalid path.");
    }
    if (!publicFiles.has(requestedFile) ||
        requestedFile.includes("\\")) {
        return res.sendStatus(404);
    }
    return servePublicFile(req, res, next);
});

app.use((req, res) => {
    if (req.path.startsWith("/api/")) {
        return res.status(404).json({ error: "API endpoint not found." });
    }
    return res.status(404).send("Page not found.");
});

app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    console.error("Unhandled request error:", error);
    if (req.path.startsWith("/api/")) {
        if (error.type === "entity.parse.failed") {
            return res.status(400).json({ error: "Request body must be valid JSON." });
        }
        if (error.type === "entity.too.large") {
            return res.status(413).json({ error: "Request body is too large." });
        }
        return res.status(500).json({ error: "The request could not be completed." });
    }
    return res.status(500).send("The request could not be completed.");
});

const server = app.listen(port, "127.0.0.1", () => {
    console.log(`PURE EV showroom running at http://127.0.0.1:${port}`);
    console.log(`Protected admin sign-in: http://127.0.0.1:${port}/admin`);
    console.log(`SQLite visitor database: ${path.join(projectRoot, "database", "visitors.sqlite")}`);
});

function shutdown() {
    server.close(() => {
        database.close();
        process.exit(0);
    });
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
