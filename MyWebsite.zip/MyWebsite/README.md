# PURE EV ePluto 7G Showroom

A responsive, single-page product showroom built with semantic HTML, CSS, and vanilla JavaScript ES modules. The existing design, scooter imagery, Tamil/English part explorer, specification animations, comparison, and gallery are retained.

The customer welcome form is frontend-only: it validates the name and Indian mobile number, stores `{ name, phone }` in the browser under `showroomUser` when local storage is available, and opens the showroom. It does not call `fetch()`, an API, or a server.

## How to run the showroom

1. Open this project in VS Code.
2. Install or enable the **Live Server** extension.
3. Right-click `index.html` and select **Open with Live Server**.
4. Do not open the JavaScript module files directly.

The optional Node.js/SQLite admin dashboard from the original project is still available separately; it is not needed to view or enter the customer showroom. Start it from PowerShell with `npm install` and `npm start`, then open <http://127.0.0.1:8000/>. The old `Taamsi.html` entry file redirects to `index.html` for Live Server compatibility.

## Project structure

```text
index.html
assets/
  fonts/
  images/
    colours/
    gallery/
    icons/
    parts/
    scooter/
    variants/
css/
  base/
  components/
  layout/
  sections/
js/
  components/
  core/
  data/
  sections/
```

The empty asset folders are reserved for future matching product artwork; supplied product photographs have been moved, not regenerated.

## Where to make changes

| Area | Main files |
| --- | --- |
| Page structure and welcome markup | `index.html` |
| Welcome validation and transition | `js/sections/welcome.js` |
| Browser-only visitor storage | `js/core/storage.js` |
| App initialization and navigation | `js/core/app.js`, `js/core/navigation.js` |
| Shared DOM references and interaction state | `js/core/state.js` |
| Variant specifications and features | `js/data/variants.js` |
| Colour/image choices | `js/data/colours.js`, `js/sections/colours.js` |
| Scooter-part content and interactions | `js/data/scooter-parts.js`, `js/sections/scooter-explorer.js` |
| Variant selection and rendering | `js/sections/variants.js` |
| Specifications and animated cards | `js/sections/specifications.js`, `js/sections/range.js`, `js/sections/battery.js` |
| Feature cards and comparison | `js/sections/features.js`, `js/sections/comparison.js` |
| Gallery | `js/sections/gallery.js` |
| Shared visual and image behavior | `js/components/animations.js`, `js/core/images.js` |
| CSS entry point | `css/main.css` |
| Responsive breakpoints | `css/layout/responsive.css` |
| Section-specific styles | `css/sections/` |
| Reusable controls and form styles | `css/components/` |
| Product photographs | `assets/images/` |

Variant and specification values are maintained in one central data object. Product photos remain shared references where the supplied assets do not identify a specific model.

## Optional admin dashboard

The original admin application (`server.js`, `routes/`, `database/`, `admin.html`, and its assets) remains separate from the customer entry flow. It requires Node.js and npm, creates its SQLite database automatically, and provides the existing protected visitor dashboard. The local admin password defaults to `TAAM2024`; to change it in code, edit `localAdminPassword` near the top of `server.js`. A `SHOWROOM_ADMIN_PASSWORD` value in `.env` overrides that local default. Production requires a configured scrypt hash as documented in `.env.example`. Keep the password out of `admin.html`, which is sent to every browser. Entries made in the frontend-only welcome form stay in that browser and are not sent to the admin database.
