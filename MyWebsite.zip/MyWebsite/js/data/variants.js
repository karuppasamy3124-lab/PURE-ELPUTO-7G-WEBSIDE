import { sharedColours } from './colours.js';

// Central source for variant specifications and feature details.
export const variants = {
    "7g": {
        name: "ePluto 7G",
        image: "assets/images/colours/red.webp",
        defaultColour: "Red",
        speed: "60 KM/H",
        range: "111–151 KM",
        officialRange: "90–151 KM",
        battery: "2.4 KWH",
        load: "150 KG",
        gradeability: "14 Degree",
        motor: "—",
        batteryType: "Lithium-ion",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "Smart BMS with Mobile App",
        connectivity: "Bluetooth",
        reverse: "Available",
        imageNote: "",
        features: [
            ["↩", "Reverse Mode", "Helps manoeuvre the scooter in reverse."],
            ["⌁", "Highly Efficient Powertrain", "PURE EV powertrain feature."],
            ["↗", "Hill-Start Assist", "Supports a controlled start on an incline."],
            ["↘", "Down-Hill Assist", "Electronic rider assistance on descents."],
            ["⚡", "Swift Throttle Response", "Responsive electric acceleration."],
            ["◎", "Parking Assist", "Assistance for low-speed parking manoeuvres."],
            ["◉", "Smart AI for Battery Longevity", "Battery-management feature listed by PURE EV."],
            ["↝", "Coasting Regeneration", "Regenerative feature listed by PURE EV."],
            ["⟲", "Smart Regenerative Braking", "Regenerative braking feature listed by PURE EV."],
            ["◌", "Enhanced Electronic Braking", "Electronic braking feature listed by PURE EV."]
        ]
    },
    pro: {
        name: "ePluto 7G PRO",
        image: "assets/images/colours/images (1).jpg",
        defaultColour: "Grey",
        speed: "60 KM/H",
        range: "131–171 KM",
        battery: "3 KWH",
        load: "150 KG",
        gradeability: "12 Degree",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",
        imageNote: "The supplied images do not identify a PRO-specific model; the available ePluto reference image is shown.",
        features: []
    },
    max: {
        name: "ePluto 7G MAX",
        image: "assets/images/colours/images.jpg",
        defaultColour: "White",
        speed: "60 KM/H",
        range: "150–211 KM",
        battery: "3.5 KWH",
        load: "150 KG",
        gradeability: "12 Degree",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",
        imageNote: "The supplied images do not identify a MAX-specific model; the available ePluto reference image is shown.",
        features: []
    },
    cx: {
        name: "ePluto 7G CX",
        image: "assets/images/variants/images (4).jpg",
        defaultColour: "Red",
        speed: "47 KM/H",
        range: "85–101 KM",
        battery: "1.8 KWH",
        load: "100 KG",
        gradeability: "7 Degree",
        motor: "—",
        batteryType: "—",
        charging: "—",
        portable: "—",
        frontBrake: "—",
        rearBrake: "—",
        tyre: "—",
        wheel: "—",
        bms: "—",
        connectivity: "—",
        reverse: "—",
        imageNote: "The supplied images do not identify a CX-specific model; the available ePluto reference image is shown.",
        features: []
    }
};

Object.entries(variants).forEach(([id, specifications]) => {
    const colours = id === "cx"
        ? sharedColours.map(colour => colour.name === "Red"
            ? { ...colour, image: "assets/images/variants/images (4).jpg", views: ["assets/images/variants/images (4).jpg"] }
            : colour)
        : sharedColours;
    Object.assign(variants[id], { id }, specifications, { colours });
});
export const variantOrder = Object.keys(variants);
