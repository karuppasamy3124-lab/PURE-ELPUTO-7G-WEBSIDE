// Shared references for the available scooter colour finishes.
export const sharedColours = [
    { name: "Red", image: "assets/images/colours/red.webp", views: ["assets/images/colours/red.webp"] },
    { name: "White", image: "assets/images/colours/images.jpg", views: ["assets/images/colours/images.jpg", "assets/images/variants/images (4).jpg", "assets/images/gallery/download (1).jpg"] },
    { name: "Grey", image: "assets/images/colours/images (1).jpg", views: ["assets/images/colours/images (1).jpg", "assets/images/gallery/images (3).jpg"] }
];
