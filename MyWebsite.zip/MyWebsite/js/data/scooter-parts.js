// General component guidance; specifications remain model-dependent.
export const partData = {
    headlight: {
        title: "Headlight",
        description: "The front lamp assembly is part of the scooter’s forward lighting and visibility setup.",
        tamil: "முன்புற விளக்கு, முன்னால் செல்லும் பாதையைப் பார்க்கவும் மற்றவர்கள் ஸ்கூட்டரை கவனிக்கவும் உதவுகிறது.",
        spec: "Lighting details vary by selected model and year.",
        features: "FRONT LIGHTING  ·  VISIBILITY  ·  MODEL-DEPENDENT DETAILS"
    },
    display: {
        title: "Rider display",
        description: "The dashboard area presents vehicle information to the rider.",
        tamil: "ஸ்கூட்டர் தொடர்பான தகவல்களை ஓட்டுநருக்குக் காட்டும் பகுதி இது.",
        spec: "Display functions vary by selected model and year.",
        features: "DASHBOARD AREA  ·  RIDER INFORMATION"
    },
    indicator: {
        title: "Indicator area",
        description: "The visible indicator area is part of the scooter’s signalling and visibility equipment.",
        tamil: "திரும்பும் திசையை மற்றவர்களுக்கு தெரிவிக்க இந்த சிக்னல் விளக்குகள் பயன்படுகின்றன.",
        spec: "Indicator equipment and operation vary by model and year.",
        features: "SIGNALLING  ·  RIDER VISIBILITY"
    },
    frontTyre: {
        title: "Front tyre",
        description: "The front tyre meets the road and supports steering, grip, and ride comfort.",
        tamil: "முன் டயர் சாலையுடன் தொடர்பில் இருந்து பிடிப்பு, திசை கட்டுப்பாடு மற்றும் பயண வசதிக்கு உதவுகிறது.",
        spec: "Tyre type and size vary by selected model and year.",
        features: "ROAD CONTACT  ·  STEERING  ·  GRIP"
    },
    rearTyre: {
        title: "Rear tyre",
        description: "The rear tyre supports road contact and transfers drive force to the road.",
        tamil: "பின் டயர் சாலையுடன் பிடிப்பை வழங்கி, மோட்டாரின் இயக்கத்தை சாலைக்கு கடத்த உதவுகிறது.",
        spec: "Tyre type and size vary by selected model and year.",
        features: "ROAD CONTACT  ·  DRIVE TRACTION"
    },
    battery: {
        title: "Battery area",
        description: "The battery stores electrical energy for the scooter’s electric drive system.",
        tamil: "ஸ்கூட்டரின் மின்சார இயக்கத்திற்குத் தேவையான ஆற்றலை பேட்டரி சேமிக்கிறது.",
        spec: "Battery chemistry and capacity vary by selected model and year.",
        features: "ENERGY STORAGE  ·  VEHICLE POWER"
    },
    seat: {
        title: "Seat",
        description: "The seat is the rider and passenger seating area, shaped for everyday use.",
        tamil: "ஓட்டுநரும் பயணியும் அமர்ந்து செல்லும் பகுதி இருக்கை.",
        spec: "Seat dimensions and finish vary by model.",
        features: "RIDER COMFORT  ·  EVERYDAY PRACTICALITY"
    },
    motor: {
        title: "Electric motor area",
        description: "The electric drive system converts stored electrical energy into motion.",
        tamil: "சேமிக்கப்பட்ட மின்சாரத்தை ஸ்கூட்டரை இயக்கும் சக்தியாக மோட்டார் மாற்றுகிறது.",
        spec: "Motor output varies by selected model and year.",
        features: "ELECTRIC DRIVE  ·  REAR-WHEEL MOTION"
    },
    handlebar: {
        title: "Handlebar",
        description: "The handlebar provides the rider with steering and hand-control points.",
        tamil: "ஸ்கூட்டரின் திசையை மாற்றவும் கை கட்டுப்பாடுகளை இயக்கவும் ஹேண்டில்பார் உதவுகிறது.",
        spec: "Control layout may vary by model.",
        features: "STEERING  ·  RIDER CONTROLS"
    },
    frontSuspension: {
        title: "Front suspension",
        description: "The front suspension area helps manage road movement at the front wheel.",
        tamil: "முன் சக்கரத்தில் ஏற்படும் சாலை அதிர்வுகளை கையாள சஸ்பென்ஷன் உதவுகிறது.",
        spec: "Suspension construction varies by model.",
        features: "FRONT-WHEEL SUPPORT  ·  RIDE COMFORT"
    },
    frontBrake: {
        title: "Front disc brake",
        description: "The visible front disc assembly is part of the scooter’s braking system.",
        tamil: "முன் சக்கரத்தின் வேகத்தை கட்டுப்படுத்தும் பிரேக் அமைப்பின் பகுதி இது.",
        spec: "Brake type and equipment vary by selected model and year.",
        features: "CONTROLLED DECELERATION  ·  FRONT-WHEEL BRAKING"
    },
    rearBrake: {
        title: "Rear brake area",
        description: "The rear braking assembly contributes to the scooter’s overall braking system.",
        tamil: "ஸ்கூட்டரின் வேகத்தை குறைக்க பின்புற பிரேக் அமைப்பு உதவுகிறது.",
        spec: "Brake type and equipment vary by selected model and year.",
        features: "REAR-WHEEL BRAKING  ·  MODEL-DEPENDENT DETAILS"
    },
    storage: {
        title: "Under-seat storage",
        description: "The area beneath the seat is the scooter’s under-seat storage location.",
        tamil: "இருக்கையின் கீழே சிறிய பொருட்களை வைக்க பயன்படும் சேமிப்பு இடம் உள்ளது.",
        spec: "Storage capacity and access details vary by model.",
        features: "PRACTICAL STORAGE  ·  CHECK THE SELECTED MODEL"
    },
    sidePanel: {
        title: "Side body panel",
        description: "The side panel shapes the scooter’s profile and covers part of the body structure.",
        tamil: "ஸ்கூட்டரின் பக்க வடிவத்தை உருவாக்கி உட்புற அமைப்பின் ஒரு பகுதியை மூடும் வெளிப்புற பேனல் இது.",
        spec: "Panel finish and detailing vary by colour and model.",
        features: "BODYWORK  ·  MODEL STYLING"
    },
    footboard: {
        title: "Footboard",
        description: "The footboard provides a space for the rider’s feet while seated.",
        tamil: "ஓட்டுநர் அமர்ந்து செல்லும்போது கால்களை வைக்க உதவும் தளம் இது.",
        spec: "Footboard layout varies by model.",
        features: "RIDER POSITION  ·  EVERYDAY COMFORT"
    },
    chargingPort: {
        title: "Charging-port area",
        description: "The charging connection is used to connect the vehicle to its compatible charger.",
        tamil: "பொருத்தமான சார்ஜரை இணைத்து ஸ்கூட்டரை சார்ஜ் செய்யும் இடம் இது.",
        spec: "Port position and charging details vary by selected model and year.",
        features: "CHARGING ACCESS  ·  USE THE SUPPLIED COMPATIBLE CHARGER"
    },
    tailLight: {
        title: "Rear-light area",
        description: "The rear lighting area helps make the scooter visible from behind.",
        tamil: "பின்னால் வரும் வாகனங்களுக்கு ஸ்கூட்டர் தெளிவாகத் தெரிய பின்புற விளக்கு உதவுகிறது.",
        spec: "Rear-light equipment varies by model and year.",
        features: "REAR VISIBILITY  ·  MODEL-DEPENDENT LIGHTING"
    },
    frontMudguard: {
        title: "Front mudguard",
        description: "The front mudguard covers part of the front wheel area.",
        tamil: "முன் சக்கரத்தின் ஒரு பகுதியை மூடும் முன்புற பாதுகாப்புப் பகுதி இது.",
        spec: "Construction and finish vary by model.",
        features: "FRONT BODYWORK · MODEL DETAIL"
    },
    rearBody: {
        title: "Rear body panel",
        description: "The rear bodywork shapes the scooter's side and rear profile.",
        tamil: "ஸ்கூட்டரின் பக்க மற்றும் பின்புற வடிவத்தை உருவாக்கும் உடல் பகுதி இது.",
        spec: "Panel finish varies by colour and model.",
        features: "REAR BODYWORK · MODEL STYLING"
    }
};
