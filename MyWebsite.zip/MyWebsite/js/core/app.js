import { initializeVisualEffects } from '../components/animations.js';
import { initializeImageFallbacks } from './images.js';
import './navigation.js';
import '../sections/welcome.js';
import { renderVariants, updateVariant } from '../sections/variants.js';
import { renderComparison } from '../sections/comparison.js';
import { initializeBatteryAnimation } from '../sections/battery.js';

initializeVisualEffects();
initializeImageFallbacks();
renderVariants();
renderComparison();
updateVariant('7g');
initializeBatteryAnimation();
