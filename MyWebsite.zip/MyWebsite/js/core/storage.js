export function saveShowroomUser(name, phone) {
    try { localStorage.setItem('showroomUser', JSON.stringify({ name, phone })); return true; }
    catch { return false; }
}
