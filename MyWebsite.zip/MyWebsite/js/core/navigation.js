import { dom, state } from './state.js';
import { closePartModal } from '../sections/scooter-explorer.js';

dom.menuButton.addEventListener("click", () => {

    dom.navMenu.classList.toggle("open");
    dom.menuButton.setAttribute(
        "aria-expanded",
        String(dom.navMenu.classList.contains("open"))
    );

});


document.querySelectorAll(".navbar nav a")
    .forEach(link => {

        link.addEventListener("click", () => {

            dom.navMenu.classList.remove("open");
            dom.menuButton.setAttribute("aria-expanded", "false");

        });

    });


/* =====================================================
   CREATE VARIANT CARDS
===================================================== */

document.addEventListener("keydown", event => {

    if (event.key === "Escape") {

        if (dom.partsViewer.classList.contains("is-focused")) {
            closePartModal();
        }
        dom.navMenu.classList.remove("open");
        dom.menuButton.setAttribute("aria-expanded", "false");

    }

    if (event.key === "Tab" && dom.partsViewer.classList.contains("is-focused")) {
        const closeButton = document.getElementById("closeModal");
        event.preventDefault();
        closeButton.focus();
    }

});
