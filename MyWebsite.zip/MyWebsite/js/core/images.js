export function initializeImageFallbacks() {
document.querySelectorAll("img")
    .forEach(img => {

        img.addEventListener("load", () => {
            delete img.dataset.fallbackAttempted;
        });

        img.addEventListener("error", () => {
            const currentFile = new URL(img.src, document.baseURI).pathname;
            if (currentFile.endsWith("/assets/images/colours/red.webp") || img.dataset.fallbackAttempted) {
                img.hidden = true;
                return;
            }
            img.dataset.fallbackAttempted = "true";
            img.src = new URL("assets/images/colours/red.webp", document.baseURI).href;

        });

    });


/* =====================================================
   INITIALIZE
===================================================== */
}
