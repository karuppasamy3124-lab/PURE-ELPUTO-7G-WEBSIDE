import { dom, state } from '../core/state.js';
import { saveShowroomUser } from '../core/storage.js';
import { updateVariant } from './variants.js';

const fullNameInput = document.getElementById("fullName");
const phoneInput = document.getElementById("phone");

fullNameInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        event.preventDefault();
        phoneInput.focus();
    }
});

dom.entryForm.addEventListener("submit", function (event) {

    event.preventDefault();

    const name =
        document.getElementById("fullName").value.trim();

    const phone =
        document.getElementById("phone").value.trim();

    const nameError =
        document.getElementById("nameError");

    const phoneError =
        document.getElementById("phoneError");

    const entryStatus =
        document.getElementById("entryStatus");

    const submitButton =
        dom.entryForm.querySelector('button[type="submit"]');
    const submitLabel =
        document.getElementById("entryButtonLabel");


    nameError.textContent = "";
    phoneError.textContent = "";
    entryStatus.textContent = "";
    entryStatus.classList.remove("error");

    let valid = true;


    if (!name) {
        nameError.textContent =
            "Please enter your name.";

        valid = false;
    }


    const indianPhone =
        /^[6-9][0-9]{9}$/;


    if (!indianPhone.test(phone)) {

        phoneError.textContent =
            "Enter a valid 10-digit Indian mobile number.";

        valid = false;
    }


    if (!valid) {
        return;
    }

    submitButton.disabled = true;
    submitButton.setAttribute("aria-busy", "true");
    submitLabel.textContent = "ENTERING SHOWROOM...";
    entryStatus.textContent = "Entering Showroom...";

    if (!saveShowroomUser(name, phone)) {
        entryStatus.textContent =
            "Entering Showroom... Your browser did not allow saving these details.";
    }

    window.setTimeout(() => {
        dom.welcomePage.style.transition =
            "opacity .7s ease, transform .7s ease";

        dom.welcomePage.style.opacity = "0";
        dom.welcomePage.style.transform = "scale(1.03)";

        window.setTimeout(() => {
            dom.welcomePage.style.display = "none";
            dom.mainWebsite.classList.add("active");
            document.body.classList.remove("no-scroll");
            updateVariant(state.selectedVariant);
            window.scrollTo({
                top: 0,
                behavior: "instant"
            });
        }, 700);
    }, 180);

});

/* =====================================================
   NAVIGATION
===================================================== */
