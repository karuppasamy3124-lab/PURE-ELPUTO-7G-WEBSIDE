export function updateRange(variant) {
    document.getElementById("rangeValue").textContent = variant.range;
}
