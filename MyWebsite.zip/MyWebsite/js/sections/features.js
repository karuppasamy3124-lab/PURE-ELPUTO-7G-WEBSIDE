export function renderFeatures(variant) {
    const featureGrid = document.getElementById("experienceGrid");
    featureGrid.replaceChildren();
    const featureList = variant.features.length
        ? variant.features
        : [["◎", "Variant details", "Feature equipment for this brochure variant has not been independently verified."]];

    featureList.forEach(([icon, title, description]) => {
        const card = document.createElement("article");
        card.className = "experience-card";
        const symbol = document.createElement("div");
        symbol.className = "experience-icon";
        symbol.setAttribute("aria-hidden", "true");
        symbol.textContent = icon;
        const heading = document.createElement("h3");
        heading.textContent = title;
        const detail = document.createElement("p");
        detail.textContent = description;
        card.append(symbol, heading, detail);
        featureGrid.appendChild(card);
    });
}
