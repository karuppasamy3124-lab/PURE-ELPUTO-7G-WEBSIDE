import { variants } from '../data/variants.js';
import { dom, state } from '../core/state.js';
import { transitionImage, updateImageSurfaces } from '../components/animations.js';
import { closePartModal } from './scooter-explorer.js';
import { resetGallery } from './gallery.js';

export function renderColours(variant) {

    dom.colourButtons.innerHTML = "";


    variant.colours.forEach((colour, index) => {

        const button =
            document.createElement("button");

        button.className = "colour-btn";
        button.type = "button";
        button.setAttribute("aria-pressed", String(colour.name === state.selectedColour.name));

        if (colour.name === state.selectedColour.name) {
            button.classList.add("active");
        }


        button.textContent =
            colour.name;


        button.addEventListener("click", () => {

            selectColour(colour);

        });


        dom.colourButtons.appendChild(button);

    });


    document.getElementById("colourDisplay")
        .textContent = state.selectedColour.name;

}


export function selectColour(colour) {

    state.selectedColour = colour;


    transitionImage(dom.heroScooter, colour.image);
    transitionImage(dom.colourScooter, colour.image);
    transitionImage(dom.partsScooter, colour.image);
    transitionImage(dom.detailCropImage, colour.image);
    updateImageSurfaces(colour);


    document.getElementById(
        "selectedColourName"
    ).textContent = colour.name;


    document.getElementById(
        "colourDisplay"
    ).textContent = colour.name;


    document.querySelectorAll(".colour-btn")
        .forEach(button => {

            button.classList.remove("active");
        button.setAttribute("aria-pressed", "false");

        if (button.textContent === colour.name) {
            button.classList.add("active");
            button.setAttribute("aria-pressed", "true");
        }

    });

    document.getElementById("colourAssetNote").textContent =
    variants[state.selectedVariant].imageNote || "";
    dom.partsScooter.alt =
    `Interactive ${variants[state.selectedVariant].name} in ${colour.name}`;
    closePartModal();
    resetGallery();

}

