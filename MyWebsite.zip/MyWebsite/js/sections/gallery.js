import { variants } from '../data/variants.js';
import { dom, state } from '../core/state.js';


dom.partsViewer.addEventListener("pointerdown", pauseGalleryRotation);


function getGalleryFrames() {
    return state.selectedColour && state.selectedColour.views
        ? state.selectedColour.views
        : [state.selectedColour
            ? state.selectedColour.image
            : "assets/images/colours/red.webp"];
}


function renderGalleryControls() {
    const frames = getGalleryFrames();
    const indicators = document.getElementById("viewIndicators");
    indicators.replaceChildren();
    document.getElementById("viewerNote").textContent = frames.length > 1
        ? "Drag, swipe, or use the controls to move between supplied product photos. This is a multi-view presentation, not a true 360° camera model."
        : "Only one suitable product image is available for this selection. Add more matching ePluto 7G photos to enable multi-view movement.";

    frames.forEach((frame, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "view-indicator";
        button.setAttribute("aria-label", `Show available product image ${index + 1}`);
        button.setAttribute("aria-pressed", String(index === state.selectedView));
        button.classList.toggle("active", index === state.selectedView);
        button.addEventListener("click", () => {
            pauseGalleryRotation();
            showGalleryView(index);
        });
        indicators.appendChild(button);
    });

    document.getElementById("previousView").disabled = frames.length < 2;
    document.getElementById("nextView").disabled = frames.length < 2;
}


function showGalleryView(index) {
    const frames = getGalleryFrames();
    if (!frames.length) {
        return;
    }

    state.selectedView = (index + frames.length) % frames.length;
    dom.galleryImage.classList.add("is-changing");
    dom.galleryImage.src = frames[state.selectedView];
    dom.galleryImage.alt =
        `${variants[state.selectedVariant].name}, available product image ${state.selectedView + 1}`;

    document.getElementById("galleryTitle").textContent =
        `PRODUCT IMAGE ${state.selectedView + 1}`;
    document.getElementById("galleryDescription").textContent =
        `Available product photograph ${state.selectedView + 1} of ${frames.length}. These images are not a true 360° camera sequence.`;

    renderGalleryControls();
    requestAnimationFrame(() => dom.galleryImage.classList.remove("is-changing"));
}


function stopGalleryRotation() {
    window.clearTimeout(state.galleryRotationTimer);
    state.galleryRotationTimer = null;
}


export function scheduleGalleryRotation(delay) {
    stopGalleryRotation();
    window.clearTimeout(state.galleryResumeTimer);
    state.galleryResumeTimer = null;

    if (document.hidden || getGalleryFrames().length < 2 ||
        !dom.mainWebsite.classList.contains("active") ||
        dom.partsViewer.classList.contains("is-focused")) {
        return;
    }

    state.galleryRotationTimer = window.setTimeout(() => {
        showGalleryView(state.selectedView + 1);
        scheduleGalleryRotation(6500);
    }, delay);
}


export function pauseGalleryRotation() {
    stopGalleryRotation();
    window.clearTimeout(state.galleryResumeTimer);
    state.galleryResumeTimer = window.setTimeout(() => {
        scheduleGalleryRotation(6500);
    }, 8000);
}


document.getElementById("previousView").addEventListener("click", () => {
    pauseGalleryRotation();
    showGalleryView(state.selectedView - 1);
});

document.getElementById("nextView").addEventListener("click", () => {
    pauseGalleryRotation();
    showGalleryView(state.selectedView + 1);
});

[dom.galleryViewer, dom.galleryControls].forEach(element => {
    element.addEventListener("pointerdown", pauseGalleryRotation);
    element.addEventListener("keydown", pauseGalleryRotation);
    element.addEventListener("focusin", pauseGalleryRotation);
    element.addEventListener("pointerenter", event => {
        if (event.pointerType === "mouse") {
            pauseGalleryRotation();
        }
    });
});

let galleryPointerStart = null;
dom.galleryViewer.addEventListener("pointerdown", event => {
    if (event.target.closest("button")) {
        return;
    }
    galleryPointerStart = { x: event.clientX, y: event.clientY };
    if (dom.galleryViewer.setPointerCapture) {
        dom.galleryViewer.setPointerCapture(event.pointerId);
    }
});

dom.galleryViewer.addEventListener("pointerup", event => {
    if (!galleryPointerStart) {
        return;
    }
    const deltaX = event.clientX - galleryPointerStart.x;
    const deltaY = event.clientY - galleryPointerStart.y;
    galleryPointerStart = null;

    if (Math.abs(deltaX) > 38 && Math.abs(deltaX) > Math.abs(deltaY)) {
        showGalleryView(state.selectedView + (deltaX < 0 ? 1 : -1));
        pauseGalleryRotation();
    }
});

dom.galleryViewer.addEventListener("pointercancel", () => {
    galleryPointerStart = null;
});

document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
        stopGalleryRotation();
        window.clearTimeout(state.galleryResumeTimer);
    } else {
        scheduleGalleryRotation(1500);
    }
});


export function resetGallery() {
    state.selectedView = 0;
    showGalleryView(state.selectedView);
    scheduleGalleryRotation(6500);
}
