import { variants } from '../data/variants.js';
import { dom, state } from '../core/state.js';

export function initializeBatteryAnimation() {
function startBatteryAnimation() {
    const fill = document.getElementById("batteryAnimationFill");
    const value = document.getElementById("batteryPercent");
    value.textContent = variants[state.selectedVariant].battery;
    fill.style.height = "0%";
    fill.style.backgroundColor = "hsl(0 78% 54%)";

    const started = performance.now();
    const frame = now => {
        const progress = Math.min(1, (now - started) / 2900);
        fill.style.height = `${progress * 100}%`;
        fill.style.backgroundColor = `hsl(${Math.round(progress * 120)} 78% 52%)`;
        if (progress < 1) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
}


/* =====================================================
   START BATTERY WHEN SECTION IS VISIBLE
===================================================== */

const observer =
    new IntersectionObserver(entries => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                startBatteryAnimation();

                observer.disconnect();

            }

        });

    }, {
        threshold: .3
    });


observer.observe(dom.batterySection);


/* =====================================================
   COMPARISON TABLE
===================================================== */
}
