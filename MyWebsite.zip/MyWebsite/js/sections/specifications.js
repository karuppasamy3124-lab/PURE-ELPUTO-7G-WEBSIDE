import { dom, state } from '../core/state.js';

export function updateSpecifications(variant) {

    document.getElementById("specSpeed")
        .textContent = variant.speed;

    document.getElementById("specRange")
        .textContent = variant.officialRange || variant.range;

    document.getElementById("specGradeability")
        .textContent = variant.gradeability;

    document.getElementById("specMotor")
        .textContent = variant.motor;

    document.getElementById("specBattery")
        .textContent = variant.battery;

    document.getElementById("specBatteryType")
        .textContent = variant.batteryType;

    document.getElementById("specCharging")
        .textContent = variant.charging;

    document.getElementById("specPortable")
        .textContent = variant.portable;

    document.getElementById("specFrontBrake")
        .textContent = variant.frontBrake;

    document.getElementById("specRearBrake")
        .textContent = variant.rearBrake;

    document.getElementById("specTyre")
        .textContent = variant.tyre;

    document.getElementById("specWheel")
        .textContent = variant.wheel;

    document.getElementById("specLoad")
        .textContent = variant.load;

    document.getElementById("specBms")
        .textContent = variant.bms;

    document.getElementById("specConnectivity")
        .textContent = variant.connectivity;

    document.getElementById("specReverse")
        .textContent = variant.reverse;

}

export function animateSpecCards(variant) {
    if (!dom.mainWebsite.classList.contains("active")) {
        return;
    }
    const run = ++state.specAnimationRun;
    const speed = Number.parseInt(variant.speed, 10);
    const load = Number.parseInt(variant.load, 10);
    const speedElement = document.getElementById("heroSpeed");
    const rangeElement = document.getElementById("heroRange");
    const batteryElement = document.getElementById("heroBattery");
    const batteryFill = document.getElementById("heroBatteryFill");
    const loadElement = document.getElementById("heroLoad");
    const loadIcon = document.querySelector(".load-icon");
    const speedCard = speedElement.closest(".stat-card");
    const rangeCard = rangeElement.closest(".stat-card");
    const batteryCard = batteryElement.closest(".stat-card");
    const loadCard = loadElement.closest(".stat-card");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    [speedCard, rangeCard, batteryCard, loadCard].forEach(card => {
        card.classList.remove("energy-complete", "range-active", "stable");
    });
    if (state.rangeTrailTimer) {
        window.clearTimeout(state.rangeTrailTimer);
        state.rangeTrailTimer = null;
    }
    speedCard.classList.remove("electric-finish");
    speedElement.textContent = "0 KM/H";
    batteryElement.textContent = variant.battery;
    loadElement.textContent = "0 KG";
    batteryFill.style.transform = "scaleX(0)";
    batteryFill.style.backgroundColor = "hsl(0 78% 54%)";
    loadIcon.style.transform = "translateY(0)";

    const finishRange = () => {
        if (run !== state.specAnimationRun) return;
        rangeElement.textContent = variant.range;
        rangeElement.classList.remove("range-dropping");
        void rangeElement.offsetWidth;
        rangeElement.classList.add("range-dropping");
        rangeCard.classList.add("range-active");
        state.rangeTrailTimer = window.setTimeout(() => rangeCard.classList.remove("range-active"), 7000);
    };

    if (reducedMotion) {
        speedElement.textContent = variant.speed;
        finishRange();
        batteryFill.style.transform = "scaleX(1)";
        batteryFill.style.backgroundColor = "hsl(120 65% 47%)";
        loadElement.textContent = variant.load;
        speedCard.classList.add("electric-finish");
        batteryCard.classList.add("energy-complete");
        loadCard.classList.add("stable");
        return;
    }

    const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    let letterIndex = 0;
    rangeElement.classList.remove("range-dropping");
    rangeElement.textContent = letters.slice(0, 1);
    const letterTimer = window.setInterval(() => {
        if (run !== state.specAnimationRun) {
            window.clearInterval(letterTimer);
            return;
        }
        letterIndex = (letterIndex + 1) % (letters.length - 3);
        rangeElement.textContent = letters.slice(letterIndex, letterIndex + 4);
    }, 75);
    window.setTimeout(() => {
        window.clearInterval(letterTimer);
        finishRange();
    }, 650);

    const countDuration = 2700;
    const animateCount = (element, target, suffix, duration, onComplete) => {
        if (!Number.isFinite(target)) {
            element.textContent = "—";
            if (onComplete) onComplete();
            return;
        }
        const started = performance.now();
        const frame = now => {
            if (run !== state.specAnimationRun) return;
            const progress = Math.min(1, (now - started) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            element.textContent = `${Math.round(target * eased)} ${suffix}`;
            if (progress < 1) {
                requestAnimationFrame(frame);
            } else if (onComplete) {
                onComplete();
            }
        };
        requestAnimationFrame(frame);
    };

    animateCount(speedElement, speed, "KM/H", countDuration, () => {
        speedElement.textContent = variant.speed;
        speedCard.classList.add("electric-finish");
    });

    const batteryStarted = performance.now();
    const fillBattery = now => {
        if (run !== state.specAnimationRun) return;
        const progress = Math.min(1, (now - batteryStarted) / 2900);
        const hue = Math.round(120 * progress);
        batteryFill.style.transform = `scaleX(${progress})`;
        batteryFill.style.backgroundColor = `hsl(${hue} 78% 52%)`;
        if (progress < 1) {
            requestAnimationFrame(fillBattery);
        } else {
            batteryCard.classList.add("energy-complete");
        }
    };
    requestAnimationFrame(fillBattery);

    if (Number.isFinite(load)) {
        const steps = Math.ceil(load / 10);
        const loadStarted = performance.now();
        const animateLoad = now => {
            if (run !== state.specAnimationRun) return;
            const progress = Math.min(1, (now - loadStarted) / countDuration);
            const completedSteps = Math.min(steps, Math.floor(progress * steps));
            const currentLoad = progress === 1
                ? load
                : Math.min(load, completedSteps * 10);
            loadElement.textContent = `${currentLoad} KG`;
            loadIcon.style.transform = `translateY(${(currentLoad / load) * 7}px)`;
            if (progress < 1) {
                requestAnimationFrame(animateLoad);
            } else {
                loadElement.textContent = variant.load;
                loadCard.classList.add("stable");
            }
        };
        requestAnimationFrame(animateLoad);
    } else {
        loadElement.textContent = "—";
    }
}


/* =====================================================
   GALLERY
===================================================== */
