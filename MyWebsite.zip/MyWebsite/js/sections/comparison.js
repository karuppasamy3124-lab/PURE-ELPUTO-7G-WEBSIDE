import { variants } from '../data/variants.js';
import { dom } from '../core/state.js';

const comparisonRows = [

    {
        label: "Top Speed",
        key: "speed"
    },

    {
        label: "Range",
        key: "range"
    },

    {
        label: "Battery",
        key: "battery"
    },

    {
        label: "Motor",
        key: "motor"
    },

    {
        label: "Load Capacity",
        key: "load"
    },

    {
        label: "Gradeability",
        key: "gradeability"
    },

    {
        label: "Charging Time",
        key: "charging"
    },

    {
        label: "Front Brake",
        key: "frontBrake"
    },

    {
        label: "Smart BMS",
        key: "bms"
    },

    {
        label: "Connectivity",
        key: "connectivity"
    }

];


export function renderComparison() {

    const checked = [...document.querySelectorAll(".compare-check")]
            .filter(input => input.checked)
            .map(input => input.value);


    dom.compareHeader.innerHTML =
        "<th>FEATURE</th>";


    dom.compareBody.innerHTML = "";


    checked.forEach(id => {

        const variant =
            variants[id];


        const th =
            document.createElement("th");

        th.textContent =
            variant.name;

        dom.compareHeader.appendChild(th);

    });


    comparisonRows.forEach(row => {

        const tr =
            document.createElement("tr");


        const featureCell =
            document.createElement("td");

        featureCell.textContent =
            row.label;


        tr.appendChild(featureCell);


        checked.forEach(id => {

            const td =
                document.createElement("td");

            td.textContent =
                (row.key === "range" ? variants[id].officialRange : variants[id][row.key]) || "—";


            tr.appendChild(td);

        });


        dom.compareBody.appendChild(tr);

    });

}


document.querySelectorAll(
    ".compare-check"
).forEach(check => {

    check.addEventListener(
        "change",
        renderComparison
    );

});
