import { variants, variantOrder } from '../data/variants.js';
import { dom, state } from '../core/state.js';
import { transitionImage, updateImageSurfaces } from '../components/animations.js';
import { updateSpecifications, animateSpecCards } from './specifications.js';
import { renderFeatures } from './features.js';
import { updateRange } from './range.js';
import { renderColours } from './colours.js';
import { resetGallery } from './gallery.js';
import { closePartModal } from './scooter-explorer.js';

export function renderVariants() {

    dom.variantContainer.innerHTML = "";


    variantOrder.map(id => variants[id]).forEach(variant => {

        const card =
            document.createElement("button");

        card.className =
            "variant-card";
        card.type = "button";
        card.setAttribute("aria-pressed", String(variant.id === state.selectedVariant));


        if (variant.id === state.selectedVariant) {
            card.classList.add("active");
        }

        const image = document.createElement("img");
        image.src = variant.image;
        image.alt = "";

        const title = document.createElement("h3");
        title.textContent = variant.name;

        const description = document.createElement("p");
        description.textContent = variant.imageNote ||
            "Select to explore this variant and its available colours.";

        card.append(image, title, description);


        card.addEventListener("click", () => {

            updateVariant(variant.id);

        });


        dom.variantContainer.appendChild(card);

    });

}


/* =====================================================
   UPDATE VARIANT
===================================================== */

export function updateVariant(id) {

    if (!variants[id]) {
        return;
    }


    state.selectedVariant = id;

    const variant = variants[id];


    /* Default colour */

    state.selectedColour =
        variant.colours.find(colour => colour.name === variant.defaultColour) ||
        variant.colours[0];


    /* Update scooter images */

    transitionImage(dom.heroScooter, state.selectedColour.image);
    transitionImage(dom.colourScooter, state.selectedColour.image);
    transitionImage(dom.partsScooter, state.selectedColour.image);
    transitionImage(dom.detailCropImage, state.selectedColour.image);
    updateImageSurfaces(state.selectedColour);

    dom.partsScooter.alt =
        `Interactive ${variant.name} in ${state.selectedColour.name}`;

    document.getElementById("explorerVariantName")
        .textContent = variant.name;

    document.getElementById("floatingModelName")
        .textContent = variant.name;

    /* Update names */

    document.getElementById(
        "selectedVariantName"
    ).textContent = variant.name;


    document.getElementById(
        "selectedColourName"
    ).textContent = state.selectedColour.name;

    document.getElementById("colourAssetNote").textContent =
        variant.imageNote || "";

    closePartModal();

    /* Hero specifications */

    document.getElementById("heroSpeed")
        .textContent = variant.speed;

    document.getElementById("heroRange")
        .textContent = variant.range;

    document.getElementById("heroBattery")
        .textContent = variant.battery;

    document.getElementById("heroLoad")
        .textContent = variant.load;
    document.getElementById("batteryPercent")
        .textContent = variant.battery;


    /* Full specification */

    updateSpecifications(variant);


    /* Colours */

    renderColours(variant);


    /* Variant active state */

    document.querySelectorAll(".variant-card")
        .forEach(card => {

            card.classList.remove("active");
            card.setAttribute("aria-pressed", "false");

        });


    const cards =
        document.querySelectorAll(".variant-card");


    const index =
        variantOrder.indexOf(id);


    if (cards[index]) {
        cards[index].classList.add("active");
        cards[index].setAttribute("aria-pressed", "true");
    }


    /* Range */

    updateRange(variant);
    renderFeatures(variant);
    animateSpecCards(variant);


    /* Gallery */

    resetGallery();

}


/* =====================================================
   UPDATE SPECIFICATIONS
===================================================== */
