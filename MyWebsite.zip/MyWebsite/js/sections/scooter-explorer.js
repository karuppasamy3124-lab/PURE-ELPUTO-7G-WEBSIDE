import { partData } from '../data/scooter-parts.js';
import { variants } from '../data/variants.js';
import { dom, state } from '../core/state.js';
import { pauseGalleryRotation, scheduleGalleryRotation } from './gallery.js';

document.querySelectorAll(".hotspot").forEach(hotspot => {
    hotspot.addEventListener("click", () => {
        pauseGalleryRotation();
        openPartModal(hotspot);
    });
});

dom.vehicleCanvas.addEventListener("click", event => {
    if (event.target.closest(".hotspot")) {
        return;
    }

    const bounds = dom.vehicleCanvas.getBoundingClientRect();
    const pointX = event.clientX;
    const pointY = event.clientY;
    const nearestHotspot = [...dom.vehicleCanvas.querySelectorAll(".hotspot")]
        .reduce((nearest, hotspot) => {
            const marker = hotspot.getBoundingClientRect();
            const distance = Math.hypot(
                marker.left + marker.width / 2 - pointX,
                marker.top + marker.height / 2 - pointY
            );
            return !nearest || distance < nearest.distance
                ? { hotspot, distance }
                : nearest;
        }, null);

    if (nearestHotspot && pointX >= bounds.left && pointX <= bounds.right &&
        pointY >= bounds.top && pointY <= bounds.bottom) {
        pauseGalleryRotation();
        openPartModal(nearestHotspot.hotspot);
    }
});

function openPartModal(hotspot) {
    const data = partData[hotspot.dataset.part];
    if (!data) {
        return;
    }

    state.activeHotspot = hotspot;
    document.getElementById("modalTitle").textContent = data.title;
    document.getElementById("modalDescription").textContent = data.description;
    document.getElementById("modalTamil").textContent = data.tamil;
    const selectedProduct = variants[state.selectedVariant];
    document.getElementById("modalSpec").textContent = hotspot.dataset.part === "battery"
        ? `${selectedProduct.battery} · ${data.spec}`
        : data.spec;
    document.getElementById("modalFeatures").textContent = data.features;
    dom.detailCropImage.alt = `${data.title} crop from the selected scooter image`;

    document.querySelectorAll(".hotspot").forEach(button => {
        button.classList.toggle("is-selected", button === hotspot);
    });
    dom.partsViewer.classList.add("is-focused");
    dom.detailPanel.setAttribute("aria-hidden", "false");
    document.getElementById("closeModal").tabIndex = 0;
    document.body.classList.add("detail-open");

    const stageRect = dom.vehicleCanvas.getBoundingClientRect();
    const stageWidth = dom.vehicleCanvas.offsetWidth;
    const stageHeight = dom.vehicleCanvas.offsetHeight;
    const targetX = hotspot.offsetLeft + hotspot.offsetWidth / 2;
    const targetY = hotspot.offsetTop + hotspot.offsetHeight / 2;
    const isMobile = window.matchMedia("(max-width: 700px)").matches;
    const zoom = isMobile ? 1.8 : 2.25;
    const focusX = stageRect.width * (isMobile ? 0.5 : 0.38);
    const focusY = stageRect.height * (isMobile ? 0.31 : 0.44);
    const translateX = (focusX - targetX) * zoom;
    const translateY = (focusY - targetY) * zoom;
    dom.vehicleCanvas.style.transform =
        `translate3d(${translateX}px, ${translateY}px, 0) scale(${zoom})`;

    window.setTimeout(() => {
        if (state.activeHotspot === hotspot) {
            dom.partsViewer.classList.add("callout-active");
            drawCallout();
        }
    }, 850);
    document.getElementById("closeModal").focus({ preventScroll: true });
}

dom.partsViewer.addEventListener("click", event => {
    if (dom.partsViewer.classList.contains("is-focused") &&
        (event.target === dom.partsViewer ||
         event.target.classList.contains("callout-overlay") ||
         event.target.classList.contains("explorer-hint"))) {
        closePartModal();
    }
});


function drawCallout() {
    if (!state.activeHotspot || !dom.partsViewer.classList.contains("callout-active")) {
        return;
    }

    updateDetailCrop(state.activeHotspot);
    const stage = dom.partsViewer.getBoundingClientRect();
    const marker = state.activeHotspot.getBoundingClientRect();
    const panel = dom.detailPanel.getBoundingClientRect();
    const scaleX = 1000 / stage.width;
    const scaleY = 600 / stage.height;
    const x1 = ((marker.left + marker.width / 2 - stage.left) * scaleX);
    const y1 = ((marker.top + marker.height / 2 - stage.top) * scaleY);
    const x2 = ((panel.left + panel.width / 2 - stage.left) * scaleX);
    const y2 = ((panel.top + panel.height / 2 - stage.top) * scaleY);

    document.getElementById("calloutLine").setAttribute("x1", x1);
    document.getElementById("calloutLine").setAttribute("y1", y1);
    document.getElementById("calloutLine").setAttribute("x2", x2);
    document.getElementById("calloutLine").setAttribute("y2", y2);
    document.getElementById("calloutDot").setAttribute("cx", x1);
    document.getElementById("calloutDot").setAttribute("cy", y1);
}

function updateDetailCrop(hotspot) {
    if (!hotspot || !dom.detailCropImage || !dom.partsScooter.naturalWidth ||
        !dom.partsScooter.naturalHeight || !dom.detailCropImage.offsetWidth) {
        return;
    }

    const stageWidth = dom.vehicleCanvas.offsetWidth;
    const stageHeight = dom.vehicleCanvas.offsetHeight;
    const targetX = hotspot.offsetLeft + hotspot.offsetWidth / 2;
    const targetY = hotspot.offsetTop + hotspot.offsetHeight / 2;
    const imageBoxLeft = stageWidth * .02;
    const imageBoxTop = stageHeight * .03;
    const imageBoxWidth = stageWidth * .96;
    const imageBoxHeight = stageHeight * .94;
    const imageScale = Math.min(
        imageBoxWidth / dom.partsScooter.naturalWidth,
        imageBoxHeight / dom.partsScooter.naturalHeight
    );
    const displayedWidth = dom.partsScooter.naturalWidth * imageScale;
    const displayedHeight = dom.partsScooter.naturalHeight * imageScale;
    const displayedLeft = imageBoxLeft + (imageBoxWidth - displayedWidth) / 2;
    const displayedTop = imageBoxTop + (imageBoxHeight - displayedHeight) / 2;
    const focusX = Math.max(0, Math.min(1, (targetX - displayedLeft) / displayedWidth));
    const focusY = Math.max(0, Math.min(1, (targetY - displayedTop) / displayedHeight));
    const cropWidth = dom.detailCropImage.offsetWidth;
    const cropHeight = dom.detailCropImage.offsetHeight;
    const cropFit = Math.min(
        cropWidth / dom.detailCropImage.naturalWidth,
        cropHeight / dom.detailCropImage.naturalHeight
    );
    const cropContentWidth = dom.detailCropImage.naturalWidth * cropFit;
    const cropContentHeight = dom.detailCropImage.naturalHeight * cropFit;
    const cropContentLeft = (cropWidth - cropContentWidth) / 2;
    const cropContentTop = (cropHeight - cropContentHeight) / 2;
    const cropScale = window.matchMedia("(max-width: 700px)").matches ? 2.6 : 2.9;
    const cropFocusX = cropContentLeft + focusX * cropContentWidth;
    const cropFocusY = cropContentTop + focusY * cropContentHeight;
    dom.detailCropImage.style.transform =
        `translate(${cropWidth / 2 - cropFocusX * cropScale}px, ${cropHeight / 2 - cropFocusY * cropScale}px) scale(${cropScale})`;
}

dom.detailCropImage.addEventListener("load", () => {
    if (state.activeHotspot) {
        updateDetailCrop(state.activeHotspot);
    }
});

dom.partsScooter.addEventListener("load", () => {
    if (state.activeHotspot) {
        updateDetailCrop(state.activeHotspot);
    }
});


document.getElementById("closeModal").addEventListener("click", closePartModal);
window.addEventListener("resize", drawCallout);

export function closePartModal() {
    if (!dom.partsViewer || !dom.detailPanel) {
        return;
    }

    dom.partsViewer.classList.remove("is-focused", "callout-active");
    dom.vehicleCanvas.style.transform = "";
    dom.detailPanel.setAttribute("aria-hidden", "true");
    document.getElementById("closeModal").tabIndex = -1;
    document.body.classList.remove("detail-open");
    document.querySelectorAll(".hotspot").forEach(button => {
        button.classList.remove("is-selected");
    });

    if (state.activeHotspot) {
        state.activeHotspot.focus({ preventScroll: true });
    }
    state.activeHotspot = null;
    scheduleGalleryRotation(8000);
}


/* =====================================================
   BATTERY ANIMATION
===================================================== */
