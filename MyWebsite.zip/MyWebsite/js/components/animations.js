import { dom } from '../core/state.js';

export function updateImageSurfaces(colour) {
    const usesPhotographicBackground =
        colour.name === "White" || colour.name === "Grey";
    [
        ".hero-image-container",
        ".colour-preview",
        ".gallery-image-wrapper",
        ".parts-viewer"
    ].forEach(selector => {
        document.querySelector(selector).classList.toggle(
            "light-image-surface",
            usesPhotographicBackground
        );
    });
}

export function transitionImage(image, source) {
    if (image.getAttribute("src") === source) {
        return;
    }
    image.classList.add("image-switching");
    window.setTimeout(() => {
        image.addEventListener("load", () => image.classList.remove("image-switching"), { once: true });
        image.src = source;
    }, 120);
}

function playLeafIntro() {
    const intro = document.getElementById("leafIntro");
    if (!intro || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        return;
    }
    for (let index = 0; index < 30; index += 1) {
        const leaf = document.createElement("span");
        leaf.className = "leaf-intro-leaf";
        const leafColor = Math.random() < 0.5 ? "var(--leaf-color-1)" : "var(--leaf-color-2)";
        leaf.style.setProperty("--leaf-left", `${Math.random() *90}%`);
        leaf.style.setProperty("--leaf-size", `${8 + Math.random() * 12}px`);
        leaf.style.setProperty("--leaf-angle", `${Math.round(Math.random() * 360)}deg`);
        leaf.style.setProperty("--leaf-duration", `${7+ Math.random() *4}s`);
        leaf.style.setProperty("--leaf-delay", `${index *0.40+Math.random() * 0.10}s`);
        leaf.style.setProperty("--leaf-drift", `${Math.round((Math.random() - .5) * 80)}px`);
        intro.appendChild(leaf);
    }
    window.setTimeout(() => intro.replaceChildren(), 15000);
}

export function initializeVisualEffects() {
    playLeafIntro();
    window.addEventListener("load", () => {

    const loader = document.getElementById("loader");

    setTimeout(() => {

        loader.style.opacity = "0";

        setTimeout(() => {
            loader.style.display = "none";
        }, 600);

    }, 700);

});


/* =====================================================
   ENTRY FORM
===================================================== */
}
